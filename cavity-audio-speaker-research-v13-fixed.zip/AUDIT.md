# Cavity Audio — Release Audit Notes

**Date:** 2026-10-04

This file records the current release-engineering evidence and does not convert unavailable execution environments into PASS results.

## Dependency-free source/data gates

- `node scripts/final-audit.mjs` — **PASS**, 235 files scanned, 0 problems.
- `node scripts/release-audit.mjs` — **PASS**, source-only workspace; binary release verification is enforced when a Windows release artifact is present.
- `node scripts/speaker-quality-audit.mjs` — **PASS**, 774 records, 0 duplicate IDs, 0 duplicate brand/model pairs, 0 embedded response curves, no category-based response synthesis.
- `node scripts/speaker-provenance-audit.mjs` — **PASS**, all populated physical fields have auditable URLs, valid provenance status, and sensitivity reference metadata.

## Speaker DB

**PASS — static database audit.** Counts below are generated from the authoritative `src/data/speakers.json` dataset:

- 774 records
- 774 unique IDs
- 0 duplicate IDs
- 774 unique brand/model pairs
- 0 duplicate brand/model pairs
- `PARTIALLY_VERIFIED`: 192
- `UNAVAILABLE`: 3
- `UNVERIFIED`: 579
- source-backed fields: sensitivity 70, power 154, impedance 82, resonant frequency 4, voice-coil size 18, woofer size 168, frequency-response limits 171
- embedded JSON response curves: 0
- declared manufacturer/measurement/verified-database response curves: 0
- physically modeled response models: 774
- generic reference models: 603
- models derived from published bandwidth limits: 171
- embedded speaker polar/directivity data: 0

The database does not claim that every catalog record is independently web-verified. Records without source-backed fields are explicitly `UNVERIFIED` and retain `N/A` physical fields rather than guessed values.

## Environment blockers

- Required Node remains `>=22.23.3 <23`; the available runner is Node `22.16.0`.
- A fresh `npm ci` could not be completed in the sandbox because npm package transport was unavailable/incomplete.
- Full runtime tests, production build, Playwright/Electron execution, Windows packaging/signing, and live cloud verification therefore remain unverified in this environment.

## Scientific honesty

- Frequency-response bandwidth is never treated as a measured response curve.
- Scatter is not physically modeled.
- Speaker-specific polar/directivity behavior is not fabricated.
- Missing physical specifications remain `N/A` rather than estimated.
- Secondary-source specifications are explicitly labeled as such.

