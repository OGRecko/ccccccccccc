# Cavity Audio — Speaker Data Gaps

Generated 2026-10-04 from the authoritative 774-record database.

This inventory lists fields that are not currently populated with retained source evidence. It is intentionally exhaustive and is not a claim that the missing information does not exist on the internet.

| ID | Brand | Model | Status | Missing fields |
|---|---|---|---|---|
| jbl-4310 | JBL | 4310 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-l100 | JBL | L100 Century | PARTIALLY_VERIFIED | sensitivity, resonantFreq, frequency-response limits |
| altec-604e | Altec Lansing | 604E Duplex | PARTIALLY_VERIFIED | sensitivity, impedance, voiceCoil |
| altec-a7 | Altec Lansing | A7 Voice of the Theatre | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer |
| ar-3a | Acoustic Research | AR-3a | PARTIALLY_VERIFIED | sensitivity, power, resonantFreq, voiceCoil |
| klh-model-6 | KLH | Model Six | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-901 | Bose | 901 | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-heresy | Klipsch | Heresy | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| klipsch-klipschorn | Klipsch | Klipschorn | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| tannoy-monitor-gold | Tannoy | Monitor Gold 15 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-4311 | JBL | 4311 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| advent-loudspeaker | Advent | The Advent Loudspeaker | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-802 | Bose | 802 Series II | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer |
| jbl-l112 | JBL | L112 | PARTIALLY_VERIFIED | power, resonantFreq, frequency-response limits |
| eV-sentry-100 | Electro-Voice | Sentry 100 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| yamaha-ns1000m | Yamaha | NS-1000M | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil |
| jbl-4350 | JBL | 4350 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| altec-model-19 | Altec Lansing | Model 19 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| infinity-rs1 | Infinity | RS-1B | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| cerwin-vega-d9 | Cerwin Vega | D-9 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bang-olufsen-beovox-s45 | Bang & Olufsen | Beovox S45 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| eV-eliminator | Electro-Voice | Eliminator | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-4430 | JBL | 4430 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil, woofer |
| boston-a150 | Boston Acoustics | A150 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| quad-esl-63 | Quad | ESL-63 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-4.2le | Bose | 4.2LE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-1030a | Genelec | 1030A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-ns10m | Yamaha | NS-10M Studio | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-105 | KEF | Reference 105.2 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil, woofer |
| jbl-control-1 | JBL | Control 1 | PARTIALLY_VERIFIED | resonantFreq |
| genelec-1031a | Genelec | 1031A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| mackie-hr824 | Mackie | HR824 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, frequency-response limits |
| eV-sx300 | Electro-Voice | SX300 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-eon15 | JBL | EON15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-acoustimass-10 | Bose | Acoustimass 10 | UNAVAILABLE | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-kg4 | Klipsch | KG 4.5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| b&w-801 | Bowers & Wilkins | 801 Matrix | PARTIALLY_VERIFIED | sensitivity, power, resonantFreq, voiceCoil, woofer |
| genelec-1032a | Genelec | 1032A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| tannoy-system-600 | Tannoy | System 600 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| eV-force-i | Electro-Voice | Force i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-4412 | JBL | 4412 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-1029a | Genelec | 1029A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| krk-7000 | KRK | 7000B | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-lsr32 | JBL | LSR32 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-lifestyle-cube | Bose | Lifestyle Cube Speaker | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-8050a | Genelec | 8050A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| genelec-8030a | Genelec | 8030A | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| krk-rokit-5 | KRK | Rokit 5 G1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| krk-rokit-8 | KRK | Rokit 8 G3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-hs80m | Yamaha | HS80M | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-hs5 | Yamaha | HS5 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-hs8 | Yamaha | HS8 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| adam-a7 | Adam Audio | A7 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| adam-a7x | Adam Audio | A7X | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq |
| adam-s3x | Adam Audio | S3X-V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-solo6 | Focal | Solo6 Be | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| focal-twin6 | Focal | Twin6 Be | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| neumann-kh120 | Neumann | KH 120 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| neumann-kh310 | Neumann | KH 310 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, frequency-response limits |
| pmc-twotwo6 | PMC | twotwo6 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| dynaudio-bm6a | Dynaudio | BM6A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| dynaudio-lyd8 | Dynaudio | LYD 8 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| eV-zlx15p | Electro-Voice | ZLX-15P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| eV-etx15p | Electro-Voice | ETX-15P | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-eon615 | JBL | EON615 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq |
| jbl-prx815w | JBL | PRX815W | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-k12.2 | QSC | K12.2 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| qsc-k10.2 | QSC | K10.2 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| mackie-thump15a | Mackie | Thump15A | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| rcf-art312a | RCF | ART 312-A MK5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| turbosound-ip15b | Turbosound | iP15B | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-l1-compact | Bose | L1 Compact | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-s1-pro | Bose | S1 Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-charge5 | JBL | Charge 5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-flip6 | JBL | Flip 6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-partybox-1000 | JBL | PartyBox 1000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-one | Sonos | One | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-five | Sonos | Five | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sub-mini | Sonos | Sub Mini | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-sub1 | Bose | Sub1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-srx828sp | JBL | SRX828SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ks212c | QSC | KS212C | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| eV-elx200-18sp | Electro-Voice | ELX200-18SP | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| kef-ls50 | KEF | LS50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-ls50-wireless | KEF | LS50 Wireless II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-r11 | KEF | R11 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bw-805d3 | Bowers & Wilkins | 805 D3 | PARTIALLY_VERIFIED | power, impedance, resonantFreq, voiceCoil |
| bw-802d3 | Bowers & Wilkins | 802 D3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sopra2 | Focal | Sopra No.2 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| klipsch-rp8000f | Klipsch | RP-8000F | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| klipsch-r51m | Klipsch | R-51M | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| polk-rti-a7 | Polk Audio | RTi A7 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-signature-s60 | Polk Audio | Signature S60 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| martinlogan-motion-60xt | MartinLogan | Motion 60XT | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| martinlogan-esl-x | MartinLogan | ElectroMotion ESL X | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| paradigm-monitor-11 | Paradigm | Monitor SE 6000F | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil |
| revel-f206 | Revel | F206 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| revel-m106 | Revel | M106 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-olympica3 | Sonus faber | Olympica III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-diamond-12 | Wharfedale | Diamond 12.1 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| monitor-audio-silver-500 | Monitor Audio | Silver 500 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-oberon7 | Dali | Oberon 7 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| elac-uni-fi-ub5 | ELAC | Uni-Fi UB5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-control-25 | JBL | Control 25-1 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| bose-freespace-3 | Bose | FreeSpace 3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-cdt5650c | Klipsch | CDT-5650-C II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-rc85i | Polk Audio | RC85i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonance-vp86 | Sonance | Visual Performance VP86 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| bose-virtually-invisible-791 | Bose | Virtually Invisible 791 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-ns-aw392 | Yamaha | NS-AW392 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| martin-audio-cdd12 | Martin Audio | CDD12 | PARTIALLY_VERIFIED | sensitivity, resonantFreq |
| dbtechnologies-opera-405 | dB Technologies | Opera 405 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-dxr12 | Yamaha | DXR12 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-hs7 | Yamaha | HS7 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| presonus-eris-e5 | PreSonus | Eris E5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-e8 | PreSonus | Eris E8 XT | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, frequency-response limits |
| m-audio-bx5 | M-Audio | BX5 D3 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| iloud-micro-monitor | IK Multimedia | iLoud Micro Monitor | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| genelec-8010a | Genelec | 8010A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| genelec-8341a | Genelec | 8341A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| genelec-8351a | Genelec | 8351A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| eve-audio-sc207 | Eve Audio | SC207 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq |
| barefoot-micromain27 | Barefoot Sound | MicroMain27 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| amphion-one18 | Amphion | One18 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| ath-avantone-mixcube | Avantone | Mixcube | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-4429 | JBL | 4429 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-m2 | JBL | M2 Master Reference | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| eV-live-x2 | Electro-Voice | Live X X2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| peavey-sp2 | Peavey | SP 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| community-cs215 | Community | CS215 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| meyer-ups1p | Meyer Sound | UPA-1P | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, frequency-response limits |
| meyer-mjf212 | Meyer Sound | MJF-212 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dandb-t10 | d&b audiotechnik | T10 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| lacoustics-arcs | L-Acoustics | ARCS Wide | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| nexo-ps15 | Nexo | PS15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| funktion-one-res2 | Funktion-One | Res 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rcf-nx45a | RCF | NX 45-A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| behringer-b215xl | Behringer | B215XL | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-jrx225 | JBL | JRX225 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-srx815 | JBL | SRX815 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-vrx932 | JBL | VRX932LA | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-kw153 | QSC | KW153 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-vtx-a12 | JBL | VTX A12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| das-audio-aero-12a | DAS Audio | Aero 12A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| turbosound-tcs-115 | Turbosound | TCS-115 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| harbeth-shl5 | Harbeth | Super HL5 Plus | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| spendor-sp100 | Spendor | SP100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| proac-response-d2 | ProAc | Response D2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-l16 | JBL | L16 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-l19 | JBL | L19 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| boston-vr-m50 | Boston Acoustics | VR-M50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| infinity-kappa-9 | Infinity | Kappa 9 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| snell-typeAIII | Snell Acoustics | Type A/III | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| thiel-cs2.4 | Thiel | CS2.4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| vandersteen-2ce | Vandersteen | 2Ce Signature | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| magnepan-mg1.7 | Magnepan | MG 1.7 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| magnepan-mg20 | Magnepan | MG 20.1 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil, woofer |
| apogee-scintilla | Apogee Acoustics | Scintilla | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-8260a | Genelec | 8260A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| ath-focal-shape65 | Focal | Shape 65 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| ath-focal-shape40 | Focal | Shape 40 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| genelec-8331a | Genelec | 8331A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| kali-lp6 | Kali Audio | LP-6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kali-in8 | Kali Audio | IN-8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-freespace-ds16s | Bose | FreeSpace DS 16S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-freespace-ds40se | Bose | FreeSpace DS 40SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-freespace-ds100se | Bose | FreeSpace DS 100SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-designmax-dm3se | Bose | DesignMax DM3SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-designmax-dm5se | Bose | DesignMax DM5SE | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| bose-designmax-dm6se | Bose | DesignMax DM6SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-designmax-dm8se | Bose | DesignMax DM8SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-designmax-dm10se | Bose | DesignMax DM10SE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| auratone-5c | Auratone | 5C Sound Cube | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-8020c | Genelec | 8020C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-8040b | Genelec | 8040B | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-lsr305 | JBL | LSR305 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-306p-mkii | JBL | 306P MkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| fostex-6301b | Fostex | 6301B | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-901-series-vi | Bose | 901 Series VI | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-301 | Bose | 301 Series IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-linton | Wharfedale | Linton Heritage | PARTIALLY_VERIFIED | sensitivity, power, resonantFreq, voiceCoil |
| jbl-everest-dd67000 | JBL | Everest DD67000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-guarneri | Sonus faber | Guarneri Evolution | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wilson-watt-puppy | Wilson Audio | WATT/Puppy 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-utopia-scala | Focal | Scala Utopia III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| atc-scm19 | ATC | SCM19 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-t5v | Adam Audio | T5V | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq |
| behringer-truth-b2031 | Behringer | Truth B2031A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, frequency-response limits |
| equator-d5 | Equator Audio | D5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| eaw-kf760 | EAW | KF760 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adamson-e15 | Adamson | E15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| void-air-8 | Void Acoustics | Air 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| danley-sh96 | Danley Sound Labs | SH-96 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| celestion-v30 | Celestion | Vintage 30 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| celestion-greenback | Celestion | G12M Greenback | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| celestion-g12h30 | Celestion | G12H-30 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| eminence-legend | Eminence | Legend V12 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jensen-p12n | Jensen | P12N | PARTIALLY_VERIFIED | frequency-response limits |
| jensen-p10r | Jensen | P10R | PARTIALLY_VERIFIED | frequency-response limits |
| jl-audio-12w7 | JL Audio | 12W7AE-3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rockford-fosgate-p3 | Rockford Fosgate | Punch P3D4-12 (Dual 4Ω) | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kicker-compvr | Kicker | CompVR 12 (43CVR124, 4Ω DVC) | PARTIALLY_VERIFIED | frequency-response limits |
| pioneer-ts-a | Pioneer | TS-A1670F | PARTIALLY_VERIFIED | sensitivity, resonantFreq, voiceCoil, woofer |
| kef-ls3-5a | KEF | LS3/5a | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rogers-ls3-5a | Rogers | LS3/5a | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-4312 | JBL | 4312 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| eV-sentry-500 | Electro-Voice | Sentry 500 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-w60 | Wharfedale | W60 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| tannoy-autograph | Tannoy | Autograph | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| ohm-walsh-2 | Ohm Acoustics | Walsh 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bw-802-original | Bowers & Wilkins | 802 (1979 original) | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| infinity-irs-v | Infinity | IRS V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-paragon | JBL | Paragon D44000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| cerwin-vega-earthquake | Cerwin Vega | Earthquake | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| beolab-5 | Bang & Olufsen | BeoLab 5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-arc | Sonos | Arc | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-beam | Sonos | Beam Gen 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| apple-homepod | Apple | HomePod (2nd gen) | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| amazon-echo | Amazon | Echo (4th gen) | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-ns500 | Yamaha | NS-500 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-k2-s9900 | JBL | K2 S9900 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-cornwall-iv | Klipsch | Cornwall IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-forte-iv | Klipsch | Forte IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-la-scala-ii | Klipsch | La Scala II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-heresy-iv | Klipsch | Heresy IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp8060fa | Klipsch | RP-8060FA II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp6000f | Klipsch | RP-6000F II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp600m | Klipsch | RP-600M II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp500m | Klipsch | RP-500M II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-q350 | KEF | Q350 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-q750 | KEF | Q750 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-r3 | KEF | R3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-r5 | KEF | R5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-reference-1 | KEF | Reference 1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-reference-5 | KEF | Reference 5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-l82-classic | JBL | L82 Classic | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-l100-classic | JBL | L100 Classic | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| jbl-srx815p | JBL | SRX815P | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer |
| jbl-srx835p | JBL | SRX835P | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer |
| jbl-control-52 | JBL | Control 52 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-control-30 | JBL | Control 30 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-ns-6490 | Yamaha | NS-6490 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-ns-777 | Yamaha | NS-777 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-ns-5000 | Yamaha | NS-5000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bw-800-d4 | Bowers & Wilkins | 800 D4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bw-803-d4 | Bowers & Wilkins | 803 D4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bw-805-d4 | Bowers & Wilkins | 805 D4 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| genelec-8351b | Genelec | 8351B | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| genelec-8361a | Genelec | 8361A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| qsc-k8.2 | QSC | K8.2 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| eV-zlx12p | Electro-Voice | ZLX-12P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| eV-etx12p | Electro-Voice | ETX-12P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-signature-s50 | Polk Audio | Signature S50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-signature-s15 | Polk Audio | Signature S15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-srm550 | Mackie | SRM550 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-srm212 | Mackie | SRM212 V-Class | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| yamaha-dbr12 | Yamaha | DBR12 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| bose-wave-music-system | Bose | Wave Music System IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-play1 | Sonos | Play:1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-play3 | Sonos | Play:3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-play5 | Sonos | Play:5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| martinlogan-motion-40 | MartinLogan | Motion 40 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| martinlogan-motion-20 | MartinLogan | Motion 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-a4v | Adam Audio | A4V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-a5x | Adam Audio | A5X | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-a8h | Adam Audio | A8H | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-fathom-f113 | JL Audio | Fathom f113 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| svs-pb16-ultra | SVS | PB16-Ultra | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rel-s812 | REL Acoustics | S/812 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-kc62 | KEF | KC62 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| genelec-7060c | Genelec | 7060C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| totem-model1 | Totem Acoustic | Model 1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| psb-synchrony-t600 | PSB | Synchrony T600 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bryston-model-t | Bryston | Model T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-awr650sm | Klipsch | AWR-650-SM | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonance-mariner-6 | Sonance | Mariner 6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-1 | JBL | D130 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-2 | JBL | Ranger Paragon D44000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-3 | JBL | 4310 Studio Monitor | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-5 | JBL | 4311 Studio Monitor | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-6 | JBL | 4430 Studio Monitor | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-jbl-11 | JBL | Control 25 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-1 | Bowers & Wilkins | DM6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-2 | Bowers & Wilkins | 801 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-3 | Bowers & Wilkins | Matrix 801 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-4 | Bowers & Wilkins | Nautilus | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-5 | Bowers & Wilkins | 802D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-6 | Bowers & Wilkins | CM10 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-7 | Bowers & Wilkins | 800 D3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-9 | Bowers & Wilkins | CWM8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bw-10 | Bowers & Wilkins | CCM8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-1 | KEF | Concord | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-2 | KEF | Model 104 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-3 | KEF | Model 103 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-4 | KEF | Reference 105 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-5 | KEF | Q100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-7 | KEF | Blade | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-kef-9 | KEF | LS50 Meta | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| legacy-kef-10 | KEF | Ci200 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-1 | Focal | Chorus 707 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-2 | Focal | Electra 1027Be | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-3 | Focal | Utopia III Scala | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-5 | Focal | Trio6 Be | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-7 | Focal | Kanta No2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-focal-8 | Focal | Aria 906 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-yam-2 | Yamaha | NS-10M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-yam-3 | Yamaha | NS-690 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-yam-8 | Yamaha | VXC series | UNAVAILABLE | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-gen-1 | Genelec | S30 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-gen-5 | Genelec | 8050B | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| legacy-gen-8 | Genelec | 4430 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-gen-9 | Genelec | 1237A | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| legacy-klip-3 | Klipsch | Cornwall | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-klip-4 | Klipsch | La Scala | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-klip-5 | Klipsch | Forte | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-klip-6 | Klipsch | RF-7 III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-klip-8 | Klipsch | R-41M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-2 | Mackie | HR624 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-3 | Mackie | MR624 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-4 | Mackie | CR3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-5 | Mackie | Thump15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-6 | Mackie | SRM450 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-mack-7 | Mackie | DLM12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-adam-1 | Adam Audio | S3A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-adam-4 | Adam Audio | A7V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-adam-6 | Adam Audio | S2V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-1 | Pioneer | CS-99A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-2 | Pioneer | HPM-100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-3 | Pioneer | CS-88A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-4 | Pioneer | Elite S-1EX | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-5 | Pioneer | SP-BS22-LR | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-pio-6 | Pioneer | SP-FS52 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-dyn-1 | Dynaudio | Contour 1.3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-dyn-2 | Dynaudio | Special Twenty-Five | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-dyn-3 | Dynaudio | Confidence C1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-dyn-4 | Dynaudio | Evidence Platinum | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-dyn-7 | Dynaudio | Contour 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-sonos-1 | Sonos | ZonePlayer 100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-sonos-5 | Sonos | Move | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-sonos-6 | Sonos | Era 300 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bose-2 | Bose | 501 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bose-3 | Bose | 802 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bose-4 | Bose | 402 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bose-6 | Bose | FreeSpace DS 16F | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-bose-7 | Bose | 251 Environmental | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-ma-1 | Martin Audio | Wavefront 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-ma-2 | Martin Audio | F2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-ma-3 | Martin Audio | W8LM | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-ma-4 | Martin Audio | MLA | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-1 | L-Acoustics | V-DOSC | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-2 | L-Acoustics | ARCS | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-3 | L-Acoustics | Kara | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-4 | L-Acoustics | K1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-5 | L-Acoustics | K2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-6 | L-Acoustics | Syva | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| legacy-la-7 | L-Acoustics | X15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-8020d | Genelec | 8020D | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| genelec-8030c | Genelec | 8030C | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-305p-mkii | JBL | 305P MkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| jbl-308p-mkii | JBL | 308P MkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dbr15 | Yamaha | DBR15 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr8 | Yamaha | DXR8 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr10 | Yamaha | DXR10 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr15 | Yamaha | DXR15 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr10mkii | Yamaha | DXR10mkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr12mkii | Yamaha | DXR12mkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxr15mkii | Yamaha | DXR15mkII | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| yamaha-dxs12 | Yamaha | DXS12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-everse-8 | Electro-Voice | EVERSE 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-everse-12 | Electro-Voice | EVERSE 12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zlx-8-g2 | Electro-Voice | ZLX-8-G2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zlx-12-g2 | Electro-Voice | ZLX-12-G2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zlx-15-g2 | Electro-Voice | ZLX-15-G2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-10p | Electro-Voice | ELX200-10P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-12p | Electro-Voice | ELX200-12P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-15p | Electro-Voice | ELX200-15P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-10 | Electro-Voice | ELX200-10 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-12 | Electro-Voice | ELX200-12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-15 | Electro-Voice | ELX200-15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-12sp | Electro-Voice | ELX200-12SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-12s | Electro-Voice | ELX200-12S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx200-18s | Electro-Voice | ELX200-18S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evolve-30m | Electro-Voice | EVOLVE 30M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evolve-50 | Electro-Voice | EVOLVE 50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evolve-50m | Electro-Voice | EVOLVE 50M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evolve-70 | Electro-Voice | EVOLVE 70 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evolve-90 | Electro-Voice | EVOLVE 90 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-pxm-12mp | Electro-Voice | PXM-12MP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zx1 | Electro-Voice | ZX1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zx1i | Electro-Voice | ZX1i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zx3 | Electro-Voice | ZX3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zx4 | Electro-Voice | ZX4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-zx5 | Electro-Voice | ZX5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sx300pi | Electro-Voice | Sx300PI | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sx300pix | Electro-Voice | Sx300PIX | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sx100 | Electro-Voice | Sx100+ | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sx300e | Electro-Voice | Sx300E | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sx600 | Electro-Voice | Sx600 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-sb122 | Electro-Voice | Sb122 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx1122 | Electro-Voice | TX1122 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx1122fm | Electro-Voice | TX1122FM | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx1152 | Electro-Voice | TX1152 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx1152fm | Electro-Voice | TX1152FM | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx1181 | Electro-Voice | TX1181 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx2152 | Electro-Voice | TX2152 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-tx2181 | Electro-Voice | TX2181 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-12p | Electro-Voice | EKX-12P | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| electro-voice-ekx-15p | Electro-Voice | EKX-15P | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| electro-voice-ekx-12 | Electro-Voice | EKX-12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-15 | Electro-Voice | EKX-15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-15sp | Electro-Voice | EKX-15SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-18sp | Electro-Voice | EKX-18SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-15s | Electro-Voice | EKX-15S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-ekx-18s | Electro-Voice | EKX-18S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-etx-10p | Electro-Voice | ETX-10P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-etx-35p | Electro-Voice | ETX-35P | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-etx-15sp | Electro-Voice | ETX-15SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-etx-18sp | Electro-Voice | ETX-18SP | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx112 | Electro-Voice | ELX112 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx115 | Electro-Voice | ELX115 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-elx215 | Electro-Voice | ELX215 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evf-1152d | Electro-Voice | EVF-1152D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| electro-voice-evf-1152d-96 | Electro-Voice | EVF-1152D/96 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-cp8 | QSC | CP8 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| qsc-cp12 | QSC | CP12 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| qsc-cp15 | QSC | CP15 | UNAVAILABLE | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ks112 | QSC | KS112 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| qsc-ks118 | QSC | KS118 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| qsc-kla12 | QSC | KLA12 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, frequency-response limits |
| qsc-kla181 | QSC | KLA181 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, frequency-response limits |
| qsc-la108 | QSC | LA108 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-la112 | QSC | LA112 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ls118 | QSC | LS118 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-e110 | QSC | E110 | PARTIALLY_VERIFIED | resonantFreq |
| qsc-e112 | QSC | E112 | PARTIALLY_VERIFIED | resonantFreq |
| qsc-e115 | QSC | E115 | PARTIALLY_VERIFIED | resonantFreq |
| qsc-e215 | QSC | E215 | PARTIALLY_VERIFIED | resonantFreq, frequency-response limits |
| qsc-e218sw | QSC | E218SW | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ad-c4t | QSC | AD-C4T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ad-c6t | QSC | AD-C6T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ad-c8t | QSC | AD-C8T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ad-c820 | QSC | AD-C820 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| qsc-ac-c4t | QSC | AC-C4T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ac-c6t | QSC | AC-C6T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-ac-c8t | QSC | AC-C8T | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-wl3082 | QSC | WL3082 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-wl2102w | QSC | WL2102w | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-wl212-sw | QSC | WL212-sw | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-wl218-sw | QSC | WL218-sw | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-gp118-sw | QSC | GP118-sw | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-gp212-sw | QSC | GP212-sw | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| qsc-gp218-sw | QSC | GP218-sw | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-607-s3 | Bowers & Wilkins | 607 S3 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| bowers-wilkins-606-s3 | Bowers & Wilkins | 606 S3 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| bowers-wilkins-705-s3 | Bowers & Wilkins | 705 S3 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| bowers-wilkins-707-s3 | Bowers & Wilkins | 707 S3 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| bowers-wilkins-805-d4-signature | Bowers & Wilkins | 805 D4 Signature | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| bowers-wilkins-801-d4 | Bowers & Wilkins | 801 D4 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| bowers-wilkins-802-d4 | Bowers & Wilkins | 802 D4 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| bowers-wilkins-804-d4 | Bowers & Wilkins | 804 D4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-702-s3 | Bowers & Wilkins | 702 S3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-704-s3 | Bowers & Wilkins | 704 S3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-603-s3 | Bowers & Wilkins | 603 S3 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| bowers-wilkins-formation-flex | Bowers & Wilkins | Formation Flex | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-formation-wedge | Bowers & Wilkins | Formation Wedge | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-zeppelin | Bowers & Wilkins | Zeppelin | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-db1d | Bowers & Wilkins | DB1D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-db2d | Bowers & Wilkins | DB2D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-db3d | Bowers & Wilkins | DB3D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-db4s | Bowers & Wilkins | DB4S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bowers-wilkins-asw610 | Bowers & Wilkins | ASW610 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-q150 | KEF | Q150 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-r3-meta | KEF | R3 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-reference-1-meta | KEF | Reference 1 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-r5-meta | KEF | R5 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-r7-meta | KEF | R7 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-r11-meta | KEF | R11 Meta | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-reference-3-meta | KEF | Reference 3 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-reference-5-meta | KEF | Reference 5 Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-blade-meta | KEF | Blade Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-blade-two-meta | KEF | Blade Two Meta | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-lsx-ii | KEF | LSX II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-ls60-wireless | KEF | LS60 Wireless | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| kef-kf92 | KEF | KF92 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-kube-8b | KEF | KUBE-8b | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-kube-10b | KEF | KUBE-10b | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kef-kube-12b | KEF | KUBE-12b | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp-500m | Klipsch | RP-500M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp-600m | Klipsch | RP-600M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp-5000f-ii | Klipsch | RP-5000F II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rp-8000f-ii | Klipsch | RP-8000F II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-rf-8000f | Klipsch | RF-8000F | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-r-120sw | Klipsch | R-120SW | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-r-121sw | Klipsch | R-121SW | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-spl-100 | Klipsch | SPL-100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-spl-120 | Klipsch | SPL-120 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-spl-150 | Klipsch | SPL-150 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| klipsch-cdt-5800-c-ii | Klipsch | CDT-5800-C II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-alpha-50-evo | Focal | Alpha 50 Evo | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| focal-alpha-65-evo | Focal | Alpha 65 Evo | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| focal-alpha-80-evo | Focal | Alpha 80 Evo | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-shape-50 | Focal | Shape 50 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| focal-shape-80 | Focal | Shape 80 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-trio6 | Focal | Trio6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-chora-806 | Focal | Chora 806 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-chora-826 | Focal | Chora 826 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-aria-926 | Focal | Aria 926 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-aria-936 | Focal | Aria 936 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-aria-948 | Focal | Aria 948 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-kanta-n-1 | Focal | Kanta N°1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-kanta-n-2 | Focal | Kanta N°2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-kanta-n-3 | Focal | Kanta N°3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sopra-n-1 | Focal | Sopra N°1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sopra-n-2 | Focal | Sopra N°2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sopra-n-3 | Focal | Sopra N°3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-scala-utopia-evo | Focal | Scala Utopia Evo | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-maestro-utopia-evo | Focal | Maestro Utopia Evo | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-grande-utopia-em-evo | Focal | Grande Utopia EM Evo | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sub-one | Focal | Sub One | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-sub6 | Focal | Sub6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| neumann-kh-80-dsp | Neumann | KH 80 DSP | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| neumann-kh-120-ii | Neumann | KH 120 II | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| neumann-kh-150 | Neumann | KH 150 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| neumann-kh-420 | Neumann | KH 420 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| neumann-kh-750-dsp | Neumann | KH 750 DSP | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| adam-audio-t7v | ADAM Audio | T7V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-t8v | ADAM Audio | T8V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-a44h | ADAM Audio | A44H | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-a77h | ADAM Audio | A77H | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-s3h | ADAM Audio | S3H | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-s3v | ADAM Audio | S3V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| adam-audio-s5h | ADAM Audio | S5H | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-lyd-5 | Dynaudio | LYD 5 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| dynaudio-lyd-7 | Dynaudio | LYD 7 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| dynaudio-core-7 | Dynaudio | Core 7 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-core-47 | Dynaudio | Core 47 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-core-59 | Dynaudio | Core 59 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-emit-10 | Dynaudio | Emit 10 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-emit-20 | Dynaudio | Emit 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-emit-30 | Dynaudio | Emit 30 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-evoke-10 | Dynaudio | Evoke 10 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-evoke-20 | Dynaudio | Evoke 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-evoke-30 | Dynaudio | Evoke 30 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-evoke-50 | Dynaudio | Evoke 50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-contour-20i | Dynaudio | Contour 20i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-contour-30i | Dynaudio | Contour 30i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-contour-60i | Dynaudio | Contour 60i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-confidence-20 | Dynaudio | Confidence 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-confidence-30 | Dynaudio | Confidence 30 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-confidence-50 | Dynaudio | Confidence 50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-sb-1000-pro | SVS | SB-1000 Pro | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq |
| svs-sb-2000-pro | SVS | SB-2000 Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-sb-3000 | SVS | SB-3000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-sb4000 | SVS | SB4000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-sb16-ultra | SVS | SB16-Ultra | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-pb-1000-pro | SVS | PB-1000 Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-pb-2000-pro | SVS | PB-2000 Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-pb-3000 | SVS | PB-3000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| svs-pb-4000 | SVS | PB-4000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-era-100 | Sonos | Sonos Era 100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-era-300 | Sonos | Sonos Era 300 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-five | Sonos | Sonos Five | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-move-2 | Sonos | Sonos Move 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-roam-2 | Sonos | Sonos Roam 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-arc | Sonos | Sonos Arc | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-arc-ultra | Sonos | Sonos Arc Ultra | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-beam | Sonos | Sonos Beam | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonos-sonos-ray | Sonos | Sonos Ray | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-home-speaker-500 | Bose | Bose Home Speaker 500 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-home-speaker-300 | Bose | Bose Home Speaker 300 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-portable-smart-speaker | Bose | Bose Portable Smart Speaker | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-soundlink-flex | Bose | Bose SoundLink Flex | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-soundlink-max | Bose | Bose SoundLink Max | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-smart-ultra-soundbar | Bose | Bose Smart Ultra Soundbar | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-smart-soundbar | Bose | Bose Smart Soundbar | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bose-bose-tv-speaker | Bose | Bose TV Speaker | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-q990d | Samsung | Samsung HW-Q990D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-q990f | Samsung | Samsung HW-Q990F | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-q930d | Samsung | Samsung HW-Q930D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-q800d | Samsung | Samsung HW-Q800D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-q700d | Samsung | Samsung HW-Q700D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| samsung-samsung-hw-s800d | Samsung | Samsung HW-S800D | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sony-sony-bravia-theatre-bar-9 | Sony | Sony BRAVIA Theatre Bar 9 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sony-sony-bravia-theatre-bar-8 | Sony | Sony BRAVIA Theatre Bar 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sony-sony-ht-a7000 | Sony | Sony HT-A7000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sony-sony-ht-a5000 | Sony | Sony HT-A5000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sony-sony-ht-a3000 | Sony | Sony HT-A3000 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| lg-lg-s95tr | LG | LG S95TR | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| lg-lg-s90tr | LG | LG S90TR | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| lg-lg-s80tr | LG | LG S80TR | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| lg-lg-sc9s | LG | LG SC9S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1960a | Marshall | Marshall 1960A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1960b | Marshall | Marshall 1960B | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1960av | Marshall | Marshall 1960AV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1960bv | Marshall | Marshall 1960BV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1936 | Marshall | Marshall 1936 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-1936v | Marshall | Marshall 1936V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-mx112 | Marshall | Marshall MX112 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-mx212 | Marshall | Marshall MX212 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-acton-iii | Marshall | Marshall Acton III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-stanmore-iii | Marshall | Marshall Stanmore III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-woburn-iii | Marshall | Marshall Woburn III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| marshall-marshall-middleton | Marshall | Marshall Middleton | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| orange-orange-ppc108 | Orange | Orange PPC108 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| orange-orange-ppc112 | Orange | Orange PPC112 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| orange-ppc212 | Orange | PPC212 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| orange-ppc212v | Orange | PPC212V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| orange-ppc412 | Orange | PPC412 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-twin-reverb | Fender | Twin Reverb | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-deluxe-reverb | Fender | Deluxe Reverb | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-blues-junior-iv | Fender | Blues Junior IV | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-hot-rod-deluxe | Fender | Hot Rod Deluxe | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-princeton-reverb | Fender | Princeton Reverb | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-super-reverb | Fender | Super Reverb | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| fender-bassman-410 | Fender | Bassman 410 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-c1-650 | JL Audio | C1-650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-c2-650 | JL Audio | C2-650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-c3-650 | JL Audio | C3-650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-c5-650 | JL Audio | C5-650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-c7-650 | JL Audio | C7-650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-10w0v3 | JL Audio | 10W0v3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-12w0v3 | JL Audio | 12W0v3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-10w3v3 | JL Audio | 10W3v3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-12w3v3 | JL Audio | 12W3v3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jl-audio-13w7ae | JL Audio | 13W7AE | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| hertz-dieci-dsk-165-3 | Hertz | Dieci DSK 165.3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| hertz-cento-ck-165 | Hertz | Cento CK 165 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| hertz-mille-pro-mpk-165-3 | Hertz | Mille Pro MPK 165.3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| alpine-s-s65 | Alpine | S-S65 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| alpine-r-s65c | Alpine | R-S65C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| alpine-x-s65c | Alpine | X-S65C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pioneer-ts-a1607f | Pioneer | TS-A1607F | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pioneer-ts-z65f | Pioneer | TS-Z65F | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pioneer-ts-d65c | Pioneer | TS-D65C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kenwood-kfc-1666s | Kenwood | KFC-1666S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kenwood-excelon-kfc-xp6903c | Kenwood | Excelon KFC-XP6903C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rockford-fosgate-r165x3 | Rockford Fosgate | R165X3 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rockford-fosgate-r1675x2 | Rockford Fosgate | R1675X2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rockford-fosgate-t1650 | Rockford Fosgate | T1650 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| rockford-fosgate-t1650-s | Rockford Fosgate | T1650-S | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kicker-43dsc6504 | Kicker | 43DSC6504 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kicker-47ksc6504 | Kicker | 47KSC6504 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kicker-46css674 | Kicker | 46CSS674 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| kicker-46csc654 | Kicker | 46CSC654 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| morel-maximo-ultra-602 | Morel | Maximo Ultra 602 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| morel-virtus-602 | Morel | Virtus 602 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| morel-elate-carbon-62a | Morel | Elate Carbon 62A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| audison-prima-apk-165 | Audison | Prima APK 165 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| audison-voce-av-k6 | Audison | Voce AV K6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| audison-thesis-th-k2-ii-a | Audison | Thesis TH K2 II A | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-lumina-i | Sonus Faber | Lumina I | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| sonus-faber-lumina-ii | Sonus Faber | Lumina II | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| sonus-faber-lumina-iii | Sonus Faber | Lumina III | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| sonus-faber-sonetto-i | Sonus Faber | Sonetto I | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-sonetto-ii | Sonus Faber | Sonetto II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-sonetto-iii | Sonus Faber | Sonetto III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-sonetto-v | Sonus Faber | Sonetto V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-olympica-nova-i | Sonus Faber | Olympica Nova I | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-olympica-nova-ii | Sonus Faber | Olympica Nova II | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-olympica-nova-iii | Sonus Faber | Olympica Nova III | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-olympica-nova-v | Sonus Faber | Olympica Nova V | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-homage-tradition-amati | Sonus Faber | Homage Tradition Amati | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-homage-tradition-guarneri | Sonus Faber | Homage Tradition Guarneri | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sonus-faber-homage-tradition-serafino | Sonus Faber | Homage Tradition Serafino | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-oberon-1 | DALI | Oberon 1 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| dali-oberon-3 | DALI | Oberon 3 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| dali-oberon-5 | DALI | Oberon 5 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| dali-oberon-9 | DALI | Oberon 9 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-opticon-2-mk2 | DALI | Opticon 2 MK2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-opticon-6-mk2 | DALI | Opticon 6 MK2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-opticon-8-mk2 | DALI | Opticon 8 MK2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-rubicon-2 | DALI | Rubicon 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-rubicon-6 | DALI | Rubicon 6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-rubicon-8 | DALI | Rubicon 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-epicon-2 | DALI | Epicon 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-epicon-6 | DALI | Epicon 6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dali-epicon-8 | DALI | Epicon 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-diamond-12-0 | Wharfedale | Diamond 12.0 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-diamond-12-2 | Wharfedale | Diamond 12.2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-evo4-1 | Wharfedale | EVO4.1 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| wharfedale-evo4-2 | Wharfedale | EVO4.2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-bronze-50 | Monitor Audio | Bronze 50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-bronze-100 | Monitor Audio | Bronze 100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-bronze-200 | Monitor Audio | Bronze 200 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-bronze-500 | Monitor Audio | Bronze 500 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-silver-50 | Monitor Audio | Silver 50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-silver-100 | Monitor Audio | Silver 100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-silver-300 | Monitor Audio | Silver 300 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-creator-q50 | Monitor Audio | Creator Q50 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-creator-q250 | Monitor Audio | Creator Q250 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-creator-c1m | Monitor Audio | Creator C1M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-creator-c2m | Monitor Audio | Creator C2M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-creator-c3m | Monitor Audio | Creator C3M | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-platinum-100-3g | Monitor Audio | Platinum 100 3G | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| monitor-audio-platinum-200-3g | Monitor Audio | Platinum 200 3G | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-audio-reserve-r100 | Polk Audio | Reserve R100 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-audio-reserve-r200 | Polk Audio | Reserve R200 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-audio-signature-elite-es15 | Polk Audio | Signature Elite ES15 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| polk-audio-signature-elite-es20 | Polk Audio | Signature Elite ES20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| q-acoustics-3010i | Q Acoustics | 3010i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| q-acoustics-3020i | Q Acoustics | 3020i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| q-acoustics-3030i | Q Acoustics | 3030i | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| q-acoustics-5020 | Q Acoustics | 5020 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| triangle-borea-br02 | Triangle | Borea BR02 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| triangle-borea-br03 | Triangle | Borea BR03 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| triangle-comete-ez | Triangle | Comete Ez | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pmc-result6 | PMC | result6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pmc-pmc6-2 | PMC | PMC6-2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pmc-pmc8-2 | PMC | PMC8-2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-3-5 | PreSonus | Eris 3.5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-4-5 | PreSonus | Eris 4.5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-5 | PreSonus | Eris 5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-6 | PreSonus | Eris 6 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-eris-8 | PreSonus | Eris 8 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-r65 | PreSonus | R65 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| presonus-r80 | PreSonus | R80 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| krk-rokit-5-g4 | KRK | Rokit 5 G4 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, woofer |
| krk-rokit-7-g4 | KRK | Rokit 7 G4 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| krk-rokit-8-g4 | KRK | Rokit 8 G4 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| krk-rokit-10-3-g4 | KRK | Rokit 10-3 G4 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| krk-v4-s4 | KRK | V4 S4 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| krk-v6-s4 | KRK | V6 S4 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| krk-v8-s4 | KRK | V8 S4 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| mackie-cr3-x | Mackie | CR3-X | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-cr4-x | Mackie | CR4-X | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-cr5-x | Mackie | CR5-X | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-mr524 | Mackie | MR524 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-mr824 | Mackie | MR824 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-thump212 | Mackie | Thump212 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| mackie-thump215 | Mackie | Thump215 | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| mackie-thump215xt | Mackie | Thump215XT | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mackie-thump118s | Mackie | Thump118S | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil |
| vox-v212c | Vox | V212C | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| vox-v212hwx | Vox | V212HWX | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| vox-v212bn | Vox | V212BN | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mesa-boogie-rectifier-4x12 | Mesa/Boogie | Rectifier 4x12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mesa-boogie-2x12-rectifier | Mesa/Boogie | 2x12 Rectifier | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mesa-boogie-fillmore-2x12 | Mesa/Boogie | Fillmore 2x12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| mesa-boogie-lone-star-2x12 | Mesa/Boogie | Lone Star 2x12 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| peavey-6505-412 | Peavey | 6505 412 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| peavey-5150-412 | Peavey | 5150 412 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bang-olufsen-beosound-a5 | Bang & Olufsen | Beosound A5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bang-olufsen-beosound-2 | Bang & Olufsen | Beosound 2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bang-olufsen-beosound-balance | Bang & Olufsen | Beosound Balance | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| bang-olufsen-beosound-level | Bang & Olufsen | Beosound Level | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| devialet-dione | Devialet | Dione | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sennheiser-ambeo-soundbar-max | Sennheiser | AMBEO Soundbar Max | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sennheiser-ambeo-soundbar-plus | Sennheiser | AMBEO Soundbar Plus | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| sennheiser-ambeo-mini | Sennheiser | AMBEO Mini | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| atc-scm25a-pro | ATC | SCM25A Pro | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| atc-scm45a-pro | ATC | SCM45A Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| atc-scm50asl-pro | ATC | SCM50ASL Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| atc-scm100asl-pro | ATC | SCM100ASL Pro | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| dynaudio-lyd-48 | Dynaudio | LYD 48 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil, frequency-response limits |
| adam-audio-a77x | Adam Audio | A77X | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq |
| pmc-tb2 | PMC | TB2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| pmc-bb5-xbd-a | PMC | BB5 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-708p | JBL | 708P | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer |
| barefoot-footprint03 | Barefoot Sound | Footprint03 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| hedd-type-20 | HEDD | Type 20 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| ik-multimedia-iloud-mtm | IK Multimedia | iLoud MTM | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| focal-trio11-be | Focal | Trio11 Be | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| dutch-and-dutch-8c | Dutch & Dutch | 8c | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| genelec-1032c | Genelec | 1032C | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| revel-ultima-salon2 | Revel | Ultima Salon2 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| magico-m2 | Magico | M2 | PARTIALLY_VERIFIED | power, resonantFreq, voiceCoil |
| wilson-audio-alexia | Wilson Audio | Alexia | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| jbl-hdi-3800 | JBL | HDI-3800 | PARTIALLY_VERIFIED | resonantFreq, voiceCoil |
| kef-r7 | KEF | R7 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |
| meyer-sound-upj-1p | Meyer Sound | UPJ-1P | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, frequency-response limits |
| meyer-sound-leopard | Meyer Sound | LEOPARD | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, frequency-response limits |
| meyer-sound-lina | Meyer Sound | LINA | PARTIALLY_VERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, frequency-response limits |
| qsc-kw122 | QSC | KW122 | PARTIALLY_VERIFIED | sensitivity, impedance, resonantFreq, voiceCoil |
| electro-voice-x12-128 | Electro-Voice | X12-128 | UNVERIFIED | sensitivity, power, impedance, resonantFreq, voiceCoil, woofer, frequency-response limits |

**Records with at least one source-backed physical/response field:** 192
**Records with no source-backed physical/response field:** 579
**Unavailable catalog identities:** 3
