# Cavity Audio — Speaker Data Status

Generated from `src/data/speakers.json`; counts are not hand-maintained.

Updated 2026-10-04.

The authoritative dataset contains **774 speaker records**. A record is `PARTIALLY_VERIFIED` only when at least one physical specification or frequency-response limit has retained source provenance. Records with no sourced physical field are `UNVERIFIED`. `UNAVAILABLE` is reserved for unresolved catalog identities.

## Record status
- PARTIALLY_VERIFIED: 192
- UNVERIFIED: 579
- UNAVAILABLE: 3

## Current source-backed fields
- Sensitivity: 70
- Power: 154
- Impedance: 82
- Resonant frequency: 4
- Voice-coil size: 18
- Woofer size: 168
- Frequency-response limits: 171

## Response-model policy
- Embedded measured/manufacturer response curves: 0
- Models derived from published frequency limits: 171
- Generic reference models with missing published bounds: 603
- No synthesized curve is represented as a laboratory measurement.

## Directivity / scatter
- Embedded speaker polar/directivity datasets: 0
- Physical scatter model: not implemented
- Speaker selection alone does not imply speaker-specific room directivity.

## Integrity rule
A missing field is `N/A` rather than guessed. A published bandwidth is not converted into a fabricated frequency-response curve.
