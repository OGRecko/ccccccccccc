# Cavity Audio — Speaker Sources

Generated 2026-10-04 from the authoritative dataset. 178 unique source URLs are retained for populated fields.

The source is attached to the exact field it supports. A source URL here does not imply that every specification for that speaker came from the same source.

## https://amphion.fi/products/one18/

- Amphion One18 — frequency-response limits
- Amphion One18 — impedance
- Amphion One18 — power
- Amphion One18 — sensitivity
- Amphion One18 — woofer size

## https://assets.ctfassets.net/4zjnzn055a4v/4y9snIK0yIQ2qISCcWSgWc/f56eaeb05c87370834d0d0f0fd0e6a5a/1030A_sysspecs.pdf

- Genelec 1030A — frequency-response limits
- Genelec 1030A — power
- Genelec 1030A — woofer size

## https://assets.ctfassets.net/4zjnzn055a4v/5C4rCdOHwAIWM6yoQ24s6q/4091d26f60d3e5e1669800d8fdc1f625/1032A_datasheet.pdf

- Genelec 1032A — frequency-response limits
- Genelec 1032A — power
- Genelec 1032A — woofer size

## https://assets.ctfassets.net/4zjnzn055a4v/7547Y1zhZuQeaO68yMCYGe/98dd2e2995803eae08cddc2709797e38/1029A_datasheet.pdf

- Genelec 1029A — frequency-response limits
- Genelec 1029A — power
- Genelec 1029A — woofer size

## https://assets.ctfassets.net/4zjnzn055a4v/79fcscYYtUsCk4EMUiAqGM/50970fe434f18b949f772e2170b9a042/1031A_sysspecs.pdf

- Genelec 1031A — frequency-response limits
- Genelec 1031A — power
- Genelec 1031A — woofer size

## https://assets.kef.com/product-support/ls60-wireless/LS60_Wireless_Info_sheet_EN.pdf

- KEF LS60 Wireless — frequency-response limits
- KEF LS60 Wireless — power

## https://assets.klipsch.com/product-specsheets/Heresy-Spec.pdf

- Klipsch Heresy — frequency-response limits
- Klipsch Heresy — impedance
- Klipsch Heresy — power
- Klipsch Heresy — sensitivity
- Klipsch Heresy — woofer size

## https://assets.klipsch.com/product-specsheets/Klipschorn-Spec-Sheet-v04.pdf

- Klipsch Klipschorn — frequency-response limits
- Klipsch Klipschorn — impedance
- Klipsch Klipschorn — power
- Klipsch Klipschorn — sensitivity
- Klipsch Klipschorn — woofer size

## https://assets.klipsch.com/product-specsheets/R-51M_Spec-Sheet_v01.pdf

- Klipsch R-51M — frequency-response limits
- Klipsch R-51M — impedance
- Klipsch R-51M — power
- Klipsch R-51M — sensitivity
- Klipsch R-51M — woofer size

## https://assets.klipsch.com/product-specsheets/RP-8000F_Spec-Sheet.pdf

- Klipsch RP-8000F — frequency-response limits
- Klipsch RP-8000F — impedance
- Klipsch RP-8000F — power
- Klipsch RP-8000F — sensitivity
- Klipsch RP-8000F — woofer size

## https://atc.audio/professional/discontinued-pro-loudspeakers/scm25a-pro/

- ATC SCM25A Pro — frequency-response limits
- ATC SCM25A Pro — power
- ATC SCM25A Pro — woofer size

## https://audio-database.com/ALTEC/speaker/model19-e.html

- Altec Lansing Model 19 — frequency-response limits
- Altec Lansing Model 19 — impedance
- Altec Lansing Model 19 — power
- Altec Lansing Model 19 — sensitivity
- Altec Lansing Model 19 — woofer size

## https://audio-database.com/ALTEC/unit/604e.html

- Altec Lansing 604E Duplex — frequency-response limits
- Altec Lansing 604E Duplex — power
- Altec Lansing 604E Duplex — resonant frequency
- Altec Lansing 604E Duplex — woofer size

## https://audio-database.com/AR/speaker/ar-3a-e.html

- Acoustic Research AR-3a — frequency-response limits
- Acoustic Research AR-3a — impedance
- Acoustic Research AR-3a — woofer size

## https://audio-database.com/ELECTRO-VOICE/speaker/sentry100.html

- Electro-Voice Sentry 100 — frequency-response limits
- Electro-Voice Sentry 100 — impedance
- Electro-Voice Sentry 100 — power
- Electro-Voice Sentry 100 — sensitivity
- Electro-Voice Sentry 100 — woofer size

## https://audio-database.com/KEF/speaker/model105-2.html

- KEF Reference 105.2 — frequency-response limits
- KEF Reference 105.2 — impedance
- KEF Reference 105.2 — power
- KEF Reference 105.2 — sensitivity

## https://barefootsound.com/product/micromain27/

- Barefoot Sound MicroMain27 — frequency-response limits
- Barefoot Sound MicroMain27 — power

## https://boseprofessional.com/products/loudspeakers/surface-mount/designmax-surface-mount/designmax-dm5se-1-pair

- Bose DesignMax DM5SE — frequency-response limits
- Bose DesignMax DM5SE — impedance
- Bose DesignMax DM5SE — power
- Bose DesignMax DM5SE — sensitivity
- Bose DesignMax DM5SE — woofer size

## https://brand.genelec.com/web/site/1032c

- Genelec 1032C — frequency-response limits
- Genelec 1032C — power
- Genelec 1032C — woofer size

## https://campaigns.genelec.com/web/site/8050b

- Genelec 8050B — frequency-response limits
- Genelec 8050B — power
- Genelec 8050B — woofer size

## https://cdn01.4wall.com/cms/rentals/files/f67ab6de47f2f4.pdf

- Meyer Sound UPA-1P — woofer size

## https://celestion.com/product/g12h-anniversary/

- Celestion G12H-30 — frequency-response limits
- Celestion G12H-30 — impedance
- Celestion G12H-30 — power
- Celestion G12H-30 — sensitivity
- Celestion G12H-30 — woofer size

## https://celestion.com/product/g12m-greenback/

- Celestion G12M Greenback — frequency-response limits
- Celestion G12M Greenback — impedance
- Celestion G12M Greenback — power
- Celestion G12M Greenback — sensitivity
- Celestion G12M Greenback — woofer size

## https://celestion.com/product/vintage-30/

- Celestion Vintage 30 — frequency-response limits
- Celestion Vintage 30 — impedance
- Celestion Vintage 30 — power
- Celestion Vintage 30 — sensitivity
- Celestion Vintage 30 — woofer size

## https://dali-speakers.com/en-us/products/oberon/oberon-1/

- DALI Oberon 1 — frequency-response limits
- DALI Oberon 1 — impedance
- DALI Oberon 1 — power
- DALI Oberon 1 — sensitivity
- DALI Oberon 1 — woofer size

## https://docs.meyersound.com/pdf/leopard_ds_e2.pdf

- Meyer Sound LEOPARD — woofer size

## https://docs.meyersound.com/pdf/lina_ds_b2.pdf

- Meyer Sound LINA — woofer size

## https://dynaudio.com/professional-audio/classic-bm-range/bm6a

- Dynaudio BM6A — frequency-response limits
- Dynaudio BM6A — power
- Dynaudio BM6A — woofer size

## https://dynaudio.com/professional-audio/lyd/lyd-48

- Dynaudio LYD 48 — power
- Dynaudio LYD 48 — woofer size

## https://dynaudio.com/professional-audio/lyd/lyd-5

- Dynaudio LYD 5 — frequency-response limits
- Dynaudio LYD 5 — woofer size

## https://dynaudio.com/professional-audio/lyd/lyd-7

- Dynaudio LYD 7 — frequency-response limits
- Dynaudio LYD 7 — woofer size

## https://dynaudio.com/professional-audio/lyd/lyd-8

- Dynaudio LYD 8 — frequency-response limits
- Dynaudio LYD 8 — power
- Dynaudio LYD 8 — woofer size

## https://eminence.com/collections/legend-series

- Eminence Legend V12 — frequency-response limits
- Eminence Legend V12 — impedance
- Eminence Legend V12 — power
- Eminence Legend V12 — sensitivity
- Eminence Legend V12 — woofer size

## https://fullcompass.com/common/files/48041-UPJ1datasheet.pdf

- Meyer Sound UPJ-1P — power
- Meyer Sound UPJ-1P — voice-coil size
- Meyer Sound UPJ-1P — woofer size

## https://global.jbl.com/JBLL100CLASSICUAM.html

- JBL L100 Classic — frequency-response limits
- JBL L100 Classic — impedance
- JBL L100 Classic — power
- JBL L100 Classic — sensitivity
- JBL L100 Classic — woofer size

## https://global.jbl.com/JBLL82CLASSICORGAM.html

- JBL L82 Classic — frequency-response limits
- JBL L82 Classic — impedance
- JBL L82 Classic — power
- JBL L82 Classic — sensitivity
- JBL L82 Classic — woofer size

## https://global.jbl.com/studio-monitors/308PMKII.html

- JBL 308P MkII — frequency-response limits
- JBL 308P MkII — power
- JBL 308P MkII — woofer size

## https://goknight.com/content/documentation/THUMP_2022_SS.pdf

- Mackie Thump212 — frequency-response limits
- Mackie Thump212 — woofer size
- Mackie Thump215 — frequency-response limits
- Mackie Thump215 — woofer size

## https://goknight.com/content/documentation/THUMP_SUBS_2022_SS.pdf

- Mackie Thump118S — frequency-response limits
- Mackie Thump118S — woofer size

## https://in.qsc.com/products-solutions/loudspeakers/installed/passive/ceiling-mount/acousticdesign-series/ad-c820/

- QSC AD-C820 — frequency-response limits
- QSC AD-C820 — impedance
- QSC AD-C820 — power
- QSC AD-C820 — sensitivity
- QSC AD-C820 — woofer size

## https://international.kef.com/products/q150-bookshelf-speaker

- KEF Q150 — frequency-response limits
- KEF Q150 — impedance
- KEF Q150 — power
- KEF Q150 — sensitivity
- KEF Q150 — woofer size

## https://international.kef.com/products/q350-bookshelf-speaker

- KEF Q350 — frequency-response limits
- KEF Q350 — impedance
- KEF Q350 — power
- KEF Q350 — sensitivity
- KEF Q350 — woofer size

## https://international.kef.com/products/q750-floorstanding-speaker

- KEF Q750 — frequency-response limits
- KEF Q750 — impedance
- KEF Q750 — power
- KEF Q750 — sensitivity
- KEF Q750 — woofer size

## https://international.kef.com/products/r11-meta

- KEF R11 Meta — frequency-response limits
- KEF R11 Meta — impedance
- KEF R11 Meta — power
- KEF R11 Meta — sensitivity
- KEF R11 Meta — woofer size

## https://intl.presonus.com/products/eris-e8-xt-monitor

- PreSonus Eris E8 XT — power
- PreSonus Eris E8 XT — woofer size

## https://jblpro.com/en-US/products/control-25-1

- JBL Control 25-1 — frequency-response limits
- JBL Control 25-1 — impedance
- JBL Control 25-1 — power
- JBL Control 25-1 — sensitivity
- JBL Control 25-1 — woofer size

## https://jblpro.com/en-US/products/lsr305.html

- JBL LSR305 — frequency-response limits
- JBL LSR305 — power
- JBL LSR305 — woofer size

## https://jblpro.com/en-US/products/m2/1002

- JBL M2 Master Reference — frequency-response limits
- JBL M2 Master Reference — impedance
- JBL M2 Master Reference — power
- JBL M2 Master Reference — sensitivity
- JBL M2 Master Reference — woofer size

## https://jblpro.com/en-US/site_elements/4430-and-4435-information

- JBL 4430 — frequency-response limits
- JBL 4430 — impedance
- JBL 4430 — power
- JBL 4430 — sensitivity

## https://jblpro.com/en/site_elements/vintage-control-1-spec-sheet

- JBL Control 1 — frequency-response limits
- JBL Control 1 — impedance
- JBL Control 1 — power
- JBL Control 1 — sensitivity
- JBL Control 1 — voice-coil size
- JBL Control 1 — woofer size

## https://jp.yamaha.com/files/download/other_assets/7/318487/NS10MSTUDIOE.pdf

- Yamaha NS-10M Studio — frequency-response limits
- Yamaha NS-10M Studio — impedance
- Yamaha NS-10M Studio — power
- Yamaha NS-10M Studio — sensitivity
- Yamaha NS-10M Studio — woofer size

## https://mackie.com/img/file_resources/Thump12A_Thump15A_OM.pdf

- Mackie Thump15A — frequency-response limits
- Mackie Thump15A — woofer size

## https://magico.net/support/M2/M2_Owner_Manual.pdf

- Magico M2 — frequency-response limits
- Magico M2 — impedance
- Magico M2 — sensitivity
- Magico M2 — woofer size

## https://manualzz.com/doc/1623732/magneplanar-mg20.1-instruction-manual

- Magnepan MG 20.1 — frequency-response limits
- Magnepan MG 20.1 — impedance
- Magnepan MG 20.1 — sensitivity

## https://martin-audio.com/products/cdd12

- Martin Audio CDD12 — frequency-response limits
- Martin Audio CDD12 — impedance
- Martin Audio CDD12 — power
- Martin Audio CDD12 — voice-coil size
- Martin Audio CDD12 — woofer size

## https://mea.yamaha.com/en/business/audio/products/speakers/dxr/specs.html

- Yamaha DXR10 — frequency-response limits
- Yamaha DXR10 — power
- Yamaha DXR10 — woofer size
- Yamaha DXR12 — frequency-response limits
- Yamaha DXR12 — power
- Yamaha DXR12 — woofer size
- Yamaha DXR15 — frequency-response limits
- Yamaha DXR15 — power
- Yamaha DXR15 — woofer size
- Yamaha DXR8 — frequency-response limits
- Yamaha DXR8 — power
- Yamaha DXR8 — woofer size

## https://pmc-speakers.com/products/twotwo6/

- PMC twotwo6 — frequency-response limits
- PMC twotwo6 — woofer size

## https://products.bose.com/pdf/customer_service/owners/og_901.pdf

- Bose 901 Series VI — impedance
- Bose 901 Series VI — power
- Bose 901 — impedance
- Bose 901 — power

## https://products.electrovoice.com/ap/en/ekx-15p/

- Electro-Voice EKX-15P — frequency-response limits
- Electro-Voice EKX-15P — power
- Electro-Voice EKX-15P — woofer size

## https://products.electrovoice.com/ap/en/elx200-18sp

- Electro-Voice ELX200-18SP — frequency-response limits
- Electro-Voice ELX200-18SP — power
- Electro-Voice ELX200-18SP — woofer size

## https://products.electrovoice.com/binary/ETX-15P_EDS_en.pdf

- Electro-Voice ETX-15P — power

## https://products.electrovoice.com/emea/de/ekx-12p

- Electro-Voice EKX-12P — frequency-response limits
- Electro-Voice EKX-12P — power
- Electro-Voice EKX-12P — woofer size

## https://products.electrovoice.com/emea/en/sx300e

- Electro-Voice SX300 — frequency-response limits
- Electro-Voice SX300 — impedance
- Electro-Voice SX300 — power
- Electro-Voice SX300 — sensitivity
- Electro-Voice SX300 — woofer size

## https://sonance.com/products/93007

- Sonance Visual Performance VP86 — frequency-response limits
- Sonance Visual Performance VP86 — power
- Sonance Visual Performance VP86 — woofer size

## https://support.jbl.com/on/demandware.static/-/Sites-masterCatalog_Harman/default/dweb63c766/pdfs/L100_Century_Owners_Manual.pdf

- JBL L100 Century — impedance
- JBL L100 Century — power
- JBL L100 Century — voice-coil size
- JBL L100 Century — woofer size

## https://support.jbl.com/on/demandware.static/-/Sites-masterCatalog_Harman/default/dweb63c766/pdfs/L112_OM_EN.pdf

- JBL L112 — impedance
- JBL L112 — sensitivity
- JBL L112 — voice-coil size
- JBL L112 — woofer size

## https://tw.yamaha.com/files/download/other_assets/8/1249478/dxr15mkII_zh_om_a1.pdf

- Yamaha DXR10mkII — frequency-response limits
- Yamaha DXR10mkII — power
- Yamaha DXR10mkII — woofer size
- Yamaha DXR12mkII — frequency-response limits
- Yamaha DXR12mkII — power
- Yamaha DXR12mkII — woofer size
- Yamaha DXR15mkII — frequency-response limits
- Yamaha DXR15mkII — power
- Yamaha DXR15mkII — woofer size

## https://us.kef.com/products/kc62-subwoofer

- KEF KC62 — frequency-response limits
- KEF KC62 — power
- KEF KC62 — woofer size

## https://us.kef.com/products/ls50-meta

- KEF LS50 Meta — frequency-response limits
- KEF LS50 Meta — impedance
- KEF LS50 Meta — power
- KEF LS50 Meta — sensitivity
- KEF LS50 Meta — woofer size

## https://usa.yamaha.com/files/download/other_assets/0/319900/HS80M_EN.pdf

- Yamaha HS80M — frequency-response limits
- Yamaha HS80M — power
- Yamaha HS80M — woofer size

## https://usa.yamaha.com/products/audio_visual/speakers/ns_aw392/specs.html

- Yamaha NS-AW392 — frequency-response limits
- Yamaha NS-AW392 — impedance
- Yamaha NS-AW392 — power
- Yamaha NS-AW392 — sensitivity
- Yamaha NS-AW392 — woofer size

## https://usa.yamaha.com/products/proaudio/speakers/dbr/specs.html

- Yamaha DBR12 — frequency-response limits
- Yamaha DBR12 — power
- Yamaha DBR12 — woofer size
- Yamaha DBR15 — frequency-response limits
- Yamaha DBR15 — power
- Yamaha DBR15 — woofer size

## https://usa.yamaha.com/products/proaudio/speakers/hs_series/index.html

- Yamaha HS5 — frequency-response limits
- Yamaha HS5 — power
- Yamaha HS5 — woofer size
- Yamaha HS7 — frequency-response limits
- Yamaha HS7 — power
- Yamaha HS7 — woofer size
- Yamaha HS8 — frequency-response limits
- Yamaha HS8 — power
- Yamaha HS8 — woofer size

## https://www.adam-audio.com/content/uploads/2016/11/adam-audio-product-sheet-a77x_en.pdf

- Adam Audio A77X — frequency-response limits
- Adam Audio A77X — power
- Adam Audio A77X — voice-coil size
- Adam Audio A77X — woofer size

## https://www.adam-audio.com/content/uploads/2016/12/adam-audio-user-manual-A7-fr.pdf

- Adam Audio A7 — frequency-response limits
- Adam Audio A7 — woofer size

## https://www.adam-audio.com/en/ax-series/a7x/

- Adam Audio A7X — frequency-response limits
- Adam Audio A7X — voice-coil size
- Adam Audio A7X — woofer size

## https://www.adam-audio.com/en/t-series/t5v/

- Adam Audio T5V — frequency-response limits
- Adam Audio T5V — power
- Adam Audio T5V — voice-coil size
- Adam Audio T5V — woofer size

## https://www.behringer.com/en/products/0316-AAI

- Behringer Truth B2031A — power
- Behringer Truth B2031A — woofer size

## https://www.bowerswilkins.com/en-us/product/loudspeakers/603-s3/300659.html

- Bowers & Wilkins 603 S3 — frequency-response limits
- Bowers & Wilkins 603 S3 — impedance
- Bowers & Wilkins 603 S3 — power
- Bowers & Wilkins 603 S3 — sensitivity
- Bowers & Wilkins 603 S3 — woofer size

## https://www.bowerswilkins.com/en-us/product/loudspeakers/802-d4/150238-03-00-005.html

- Bowers & Wilkins 802 D4 — frequency-response limits
- Bowers & Wilkins 802 D4 — impedance
- Bowers & Wilkins 802 D4 — sensitivity
- Bowers & Wilkins 802 D4 — woofer size

## https://www.bowerswilkins.com/en-us/product/loudspeakers/805-d4/150241-01-00-005.html

- Bowers & Wilkins 805 D4 — frequency-response limits
- Bowers & Wilkins 805 D4 — impedance
- Bowers & Wilkins 805 D4 — sensitivity
- Bowers & Wilkins 805 D4 — woofer size

## https://www.bowerswilkins.com/en-us/product/system-products/607-s3/300661-01-00-005.html

- Bowers & Wilkins 607 S3 — frequency-response limits
- Bowers & Wilkins 607 S3 — impedance
- Bowers & Wilkins 607 S3 — power
- Bowers & Wilkins 607 S3 — sensitivity
- Bowers & Wilkins 607 S3 — woofer size

## https://www.bowerswilkins.com/en/product/loudspeakers/805-d4-signature/FP43745P.html

- Bowers & Wilkins 805 D4 Signature — frequency-response limits
- Bowers & Wilkins 805 D4 Signature — impedance
- Bowers & Wilkins 805 D4 Signature — sensitivity
- Bowers & Wilkins 805 D4 Signature — woofer size

## https://www.bowerswilkins.com/on/demandware.static/-/Library-Sites-bowers_europe_shared/default/dw8b9f6335/archive-manuals/805-d3-info-sheet_0.pdf

- Bowers & Wilkins 805 D3 — frequency-response limits
- Bowers & Wilkins 805 D3 — sensitivity
- Bowers & Wilkins 805 D3 — woofer size

## https://www.bowerswilkins.com/product/loudspeakers/606-s3/300660.html

- Bowers & Wilkins 606 S3 — frequency-response limits
- Bowers & Wilkins 606 S3 — impedance
- Bowers & Wilkins 606 S3 — power
- Bowers & Wilkins 606 S3 — sensitivity
- Bowers & Wilkins 606 S3 — woofer size

## https://www.bowerswilkins.com/product/loudspeakers/705-s3/300522.html

- Bowers & Wilkins 705 S3 — frequency-response limits
- Bowers & Wilkins 705 S3 — impedance
- Bowers & Wilkins 705 S3 — sensitivity
- Bowers & Wilkins 705 S3 — woofer size

## https://www.bowerswilkins.com/product/loudspeakers/707-s3/300525.html

- Bowers & Wilkins 707 S3 — frequency-response limits
- Bowers & Wilkins 707 S3 — impedance
- Bowers & Wilkins 707 S3 — sensitivity
- Bowers & Wilkins 707 S3 — woofer size

## https://www.bowerswilkins.com/product/loudspeakers/801-d4/150237-03-00-005.html

- Bowers & Wilkins 801 D4 — frequency-response limits
- Bowers & Wilkins 801 D4 — impedance
- Bowers & Wilkins 801 D4 — sensitivity
- Bowers & Wilkins 801 D4 — woofer size

## https://www.dali-speakers.com/media/5320/oberon-manual.pdf

- DALI Oberon 3 — frequency-response limits
- DALI Oberon 3 — impedance
- DALI Oberon 3 — power
- DALI Oberon 3 — sensitivity
- DALI Oberon 3 — woofer size
- DALI Oberon 5 — frequency-response limits
- DALI Oberon 5 — impedance
- DALI Oberon 5 — power
- DALI Oberon 5 — sensitivity
- DALI Oberon 5 — woofer size
- Dali Oberon 7 — frequency-response limits
- Dali Oberon 7 — impedance
- Dali Oberon 7 — power
- Dali Oberon 7 — sensitivity
- Dali Oberon 7 — woofer size

## https://www.electrovoice.com/de/produkt/etx-15p

- Electro-Voice ETX-15P — frequency-response limits
- Electro-Voice ETX-15P — woofer size

## https://www.eve-audio.com/products/sc207

- Eve Audio SC207 — frequency-response limits
- Eve Audio SC207 — power
- Eve Audio SC207 — voice-coil size
- Eve Audio SC207 — woofer size

## https://www.focal.com/en/pro-audio/solo6

- Focal Solo6 Be — frequency-response limits
- Focal Solo6 Be — power
- Focal Solo6 Be — woofer size

## https://www.focal.com/it/prodotti/sopra-n2

- Focal Sopra No.2 — frequency-response limits
- Focal Sopra No.2 — impedance
- Focal Sopra No.2 — power
- Focal Sopra No.2 — sensitivity
- Focal Sopra No.2 — woofer size

## https://www.focal.com/products/alpha-50-evo

- Focal Alpha 50 Evo — frequency-response limits
- Focal Alpha 50 Evo — woofer size

## https://www.focal.com/products/alpha-65-evo

- Focal Alpha 65 Evo — frequency-response limits
- Focal Alpha 65 Evo — power
- Focal Alpha 65 Evo — woofer size

## https://www.focal.com/products/shape-40

- Focal Shape 40 — frequency-response limits
- Focal Shape 40 — power
- Focal Shape 40 — woofer size

## https://www.focal.com/products/shape-50

- Focal Shape 50 — frequency-response limits
- Focal Shape 50 — power
- Focal Shape 50 — woofer size

## https://www.focal.com/products/shape-65

- Focal Shape 65 — frequency-response limits
- Focal Shape 65 — power
- Focal Shape 65 — woofer size

## https://www.focal.com/products/trio-11-be

- Focal Trio11 Be — frequency-response limits
- Focal Trio11 Be — power
- Focal Trio11 Be — woofer size

## https://www.focal.com/products/twin6

- Focal Twin6 Be — frequency-response limits
- Focal Twin6 Be — woofer size

## https://www.genelec.com/1237a

- Genelec 1237A — frequency-response limits
- Genelec 1237A — power
- Genelec 1237A — woofer size

## https://www.genelec.com/8010a

- Genelec 8010A — frequency-response limits
- Genelec 8010A — power

## https://www.genelec.com/8020d

- Genelec 8020D — frequency-response limits
- Genelec 8020D — power
- Genelec 8020D — woofer size

## https://www.genelec.com/8030c

- Genelec 8030A — frequency-response limits
- Genelec 8030A — woofer size
- Genelec 8030C — frequency-response limits
- Genelec 8030C — power
- Genelec 8030C — woofer size

## https://www.genelec.com/8050a

- Genelec 8050A — frequency-response limits
- Genelec 8050A — power
- Genelec 8050A — woofer size

## https://www.genelec.com/8260a

- Genelec 8260A — frequency-response limits
- Genelec 8260A — power

## https://www.genelec.com/8331a

- Genelec 8331A — frequency-response limits
- Genelec 8331A — power

## https://www.genelec.com/8341a

- Genelec 8341A — frequency-response limits
- Genelec 8341A — power

## https://www.genelec.com/8351a

- Genelec 8351A — frequency-response limits
- Genelec 8351A — power

## https://www.genelec.com/8351b

- Genelec 8351B — frequency-response limits
- Genelec 8351B — power

## https://www.genelec.com/8361a

- Genelec 8361A — frequency-response limits
- Genelec 8361A — power

## https://www.genelec.com/en/8040b

- Genelec 8040B — frequency-response limits
- Genelec 8040B — power
- Genelec 8040B — woofer size

## https://www.hifi-guide.com/loudspeaker/bowers-wilkins-801-matrix/

- Bowers & Wilkins 801 Matrix — frequency-response limits
- Bowers & Wilkins 801 Matrix — impedance

## https://www.hifi-guide.com/loudspeaker/tannoy-monitor-gold-15/

- Tannoy Monitor Gold 15 — frequency-response limits
- Tannoy Monitor Gold 15 — impedance
- Tannoy Monitor Gold 15 — power
- Tannoy Monitor Gold 15 — sensitivity
- Tannoy Monitor Gold 15 — woofer size

## https://www.hifiengine.com/manual_library/bose/802.shtml

- Bose 802 Series II — frequency-response limits
- Bose 802 Series II — impedance
- Bose 802 Series II — power

## https://www.hifiengine.com/manual_library/jbl/4310.shtml

- JBL 4310 — frequency-response limits
- JBL 4310 — impedance
- JBL 4310 — power
- JBL 4310 — sensitivity
- JBL 4310 — woofer size

## https://www.hifiengine.com/manual_library/jbl/4311.shtml

- JBL 4311 — frequency-response limits
- JBL 4311 — impedance
- JBL 4311 — power
- JBL 4311 — sensitivity
- JBL 4311 — woofer size

## https://www.hifiengine.com/manual_library/yamaha/ns-1000m.shtml

- Yamaha NS-1000M — frequency-response limits
- Yamaha NS-1000M — impedance
- Yamaha NS-1000M — power
- Yamaha NS-1000M — woofer size

## https://www.ikmultimedia.com/products/iloudmm/

- IK Multimedia iLoud Micro Monitor — frequency-response limits
- IK Multimedia iLoud Micro Monitor — woofer size

## https://www.jbl.com/305PMKII.html

- JBL 305P MkII — frequency-response limits
- JBL 305P MkII — power
- JBL 305P MkII — woofer size

## https://www.jbl.com/306PMKII.html

- JBL 306P MkII — frequency-response limits
- JBL 306P MkII — power
- JBL 306P MkII — woofer size

## https://www.jbl.com/4429.html

- JBL 4429 — frequency-response limits
- JBL 4429 — impedance
- JBL 4429 — power
- JBL 4429 — sensitivity
- JBL 4429 — woofer size

## https://www.jbl.com/708P.html

- JBL 708P — frequency-response limits

## https://www.jbl.com/HDI-3800.html

- JBL HDI-3800 — frequency-response limits
- JBL HDI-3800 — impedance
- JBL HDI-3800 — power
- JBL HDI-3800 — sensitivity
- JBL HDI-3800 — woofer size

## https://www.jbl.com/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw11bc9856/pdfs/JBL_SRX800_UsersGuide_061515.pdf

- JBL SRX815P — frequency-response limits

## https://www.jbl.com/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw93dba247/pdfs/JBL_EON600_Users_Guide.pdf

- JBL EON615 — frequency-response limits
- JBL EON615 — voice-coil size
- JBL EON615 — woofer size

## https://www.jbl.com/SRX835P.html

- JBL SRX835P — frequency-response limits

## https://www.jensentone.com/specification-sheet/36

- Jensen P10R — impedance
- Jensen P10R — power
- Jensen P10R — resonant frequency
- Jensen P10R — sensitivity
- Jensen P10R — voice-coil size
- Jensen P10R — woofer size

## https://www.jensentone.com/specification-sheet/38

- Jensen P12N — impedance
- Jensen P12N — power
- Jensen P12N — resonant frequency
- Jensen P12N — sensitivity
- Jensen P12N — voice-coil size
- Jensen P12N — woofer size

## https://www.jlaudio.com/products/f113v2-gloss-home-audio-fathom-powered-subwoofers-96142

- JL Audio Fathom f113 — frequency-response limits
- JL Audio Fathom f113 — power
- JL Audio Fathom f113 — woofer size

## https://www.kicker.com/cvr-12-4-ohm-subwoofer

- Kicker CompVR 12 (43CVR124, 4Ω DVC) — impedance
- Kicker CompVR 12 (43CVR124, 4Ω DVC) — power
- Kicker CompVR 12 (43CVR124, 4Ω DVC) — resonant frequency
- Kicker CompVR 12 (43CVR124, 4Ω DVC) — sensitivity
- Kicker CompVR 12 (43CVR124, 4Ω DVC) — voice-coil size
- Kicker CompVR 12 (43CVR124, 4Ω DVC) — woofer size

## https://www.krkmusic.com/products/rokit-10-3-generation-4-powered-studio-monitor

- KRK Rokit 10-3 G4 — frequency-response limits
- KRK Rokit 10-3 G4 — power
- KRK Rokit 10-3 G4 — woofer size

## https://www.krkmusic.com/products/rokit-5-generation-4-powered-studio-monitor-black

- KRK Rokit 5 G4 — frequency-response limits
- KRK Rokit 5 G4 — power

## https://www.krkmusic.com/products/rokit-7-generation-4-powered-studio-monitor-black

- KRK Rokit 7 G4 — frequency-response limits
- KRK Rokit 7 G4 — woofer size

## https://www.krkmusic.com/products/rokit-8-generation-4-powered-studio-monitor-black

- KRK Rokit 8 G4 — frequency-response limits
- KRK Rokit 8 G4 — power
- KRK Rokit 8 G4 — woofer size

## https://www.krkmusic.com/products/v4-series-4-powered-studio-monitor

- KRK V4 S4 — frequency-response limits
- KRK V4 S4 — power
- KRK V4 S4 — woofer size

## https://www.krkmusic.com/products/v8-series-4-powered-studio-monitor

- KRK V8 S4 — frequency-response limits
- KRK V8 S4 — power
- KRK V8 S4 — woofer size

## https://www.m-audio.com/monitors-headphones/bx5d3.html

- M-Audio BX5 D3 — frequency-response limits
- M-Audio BX5 D3 — power
- M-Audio BX5 D3 — woofer size

## https://www.manualslib.com/manual/235516/Electro-Voice-Eliminator-I.html

- Electro-Voice Eliminator — frequency-response limits
- Electro-Voice Eliminator — impedance
- Electro-Voice Eliminator — power
- Electro-Voice Eliminator — sensitivity
- Electro-Voice Eliminator — woofer size

## https://www.manualslib.com/manual/365796/Altec-Lansing-A7.html

- Altec Lansing A7 Voice of the Theatre — frequency-response limits
- Altec Lansing A7 Voice of the Theatre — impedance
- Altec Lansing A7 Voice of the Theatre — power

## https://www.manualzz.com/doc/2104058/tannoy-system-600-near-field-reference-monitor-user-manual?lang=da

- Tannoy System 600 — frequency-response limits
- Tannoy System 600 — impedance
- Tannoy System 600 — power
- Tannoy System 600 — sensitivity
- Tannoy System 600 — woofer size

## https://www.markertek.com/Attachments/Specifications/QSCAudio/E215-Specifications.pdf

- QSC E215 — impedance
- QSC E215 — power
- QSC E215 — sensitivity
- QSC E215 — voice-coil size
- QSC E215 — woofer size

## https://www.martinlogan.com/en/product/electromotion-esl-x

- MartinLogan ElectroMotion ESL X — frequency-response limits
- MartinLogan ElectroMotion ESL X — impedance
- MartinLogan ElectroMotion ESL X — power
- MartinLogan ElectroMotion ESL X — sensitivity
- MartinLogan ElectroMotion ESL X — woofer size

## https://www.martinlogan.com/en/product/motion-60xt

- MartinLogan Motion 60XT — frequency-response limits
- MartinLogan Motion 60XT — impedance
- MartinLogan Motion 60XT — power
- MartinLogan Motion 60XT — sensitivity
- MartinLogan Motion 60XT — woofer size

## https://www.neumann.com/en-be/products/monitors/kh-420

- Neumann KH 420 — frequency-response limits
- Neumann KH 420 — power
- Neumann KH 420 — woofer size

## https://www.neumann.com/en-be/products/monitors/kh-750-dsp

- Neumann KH 750 DSP — frequency-response limits
- Neumann KH 750 DSP — power
- Neumann KH 750 DSP — woofer size

## https://www.neumann.com/en-be/products/monitors/kh-80-dsp-a-g

- Neumann KH 80 DSP — frequency-response limits
- Neumann KH 80 DSP — power
- Neumann KH 80 DSP — woofer size

## https://www.neumann.com/en-gb/products/monitors/kh-120-ii

- Neumann KH 120 II — frequency-response limits
- Neumann KH 120 II — power
- Neumann KH 120 II — woofer size

## https://www.neumann.com/en-IN/products/historical/kh-120-a-g/

- Neumann KH 120 — frequency-response limits
- Neumann KH 120 — power
- Neumann KH 120 — woofer size

## https://www.neumann.com/en-us/products/monitors/kh-150-w

- Neumann KH 150 — frequency-response limits
- Neumann KH 150 — power
- Neumann KH 150 — woofer size

## https://www.neumann.com/globalassets/digizuite/1423-en-kh310-datasheet-v1.0.pdf

- Neumann KH 310 — power
- Neumann KH 310 — woofer size

## https://www.paradigm.com/en/floorstanding/monitor-se-6000f

- Paradigm Monitor SE 6000F — frequency-response limits
- Paradigm Monitor SE 6000F — impedance
- Paradigm Monitor SE 6000F — power
- Paradigm Monitor SE 6000F — woofer size

## https://www.pioneerelectronics.com/PUSA/Car/Speakers/A-Series/TS-A1670F

- Pioneer TS-A1670F — frequency-response limits
- Pioneer TS-A1670F — impedance
- Pioneer TS-A1670F — power

## https://www.polkaudio.com/en-us/product/home-speakers/signature/s60/106513.html

- Polk Audio Signature S60 — frequency-response limits
- Polk Audio Signature S60 — impedance
- Polk Audio Signature S60 — power
- Polk Audio Signature S60 — sensitivity
- Polk Audio Signature S60 — woofer size

## https://www.qsc.com/index.php?id=12775

- QSC E110 — frequency-response limits
- QSC E110 — impedance
- QSC E110 — power
- QSC E110 — sensitivity
- QSC E110 — voice-coil size
- QSC E110 — woofer size

## https://www.qsc.com/index.php?id=12780

- QSC KLA12 — woofer size
- QSC KLA181 — power
- QSC KLA181 — woofer size

## https://www.qsc.com/index.php?id=14661

- QSC E115 — frequency-response limits
- QSC E115 — impedance
- QSC E115 — power
- QSC E115 — sensitivity
- QSC E115 — voice-coil size
- QSC E115 — woofer size

## https://www.qsc.com/resource-files/productresources/spk/k.2/q_spk_k2_usermanual.pdf

- QSC K12.2 — frequency-response limits
- QSC K12.2 — power
- QSC K12.2 — woofer size

## https://www.qscaudio.com/index.php?id=12708

- QSC K10.2 — frequency-response limits
- QSC K10.2 — power
- QSC K10.2 — woofer size
- QSC K8.2 — power
- QSC K8.2 — woofer size

## https://www.qscaudio.com/products-solutions/loudspeakers/portable/powered/portable-pa/cp-series/cp8/

- QSC CP8 — frequency-response limits
- QSC CP8 — power
- QSC CP8 — woofer size

## https://www.qscaudio.com/products-solutions/loudspeakers/portable/powered/subwoofers/ks-series/ks118/

- QSC KS118 — frequency-response limits
- QSC KS118 — power
- QSC KS118 — woofer size

## https://www.qscaudio.com/resource-files/productresources/spk/e/e112/q_spk_e_112_specs.pdf

- QSC E112 — frequency-response limits
- QSC E112 — impedance
- QSC E112 — power
- QSC E112 — sensitivity
- QSC E112 — voice-coil size
- QSC E112 — woofer size

## https://www.qscaudio.com/resource-files/productresources/spk/kw/q_spk_kw_usermanual.pdf

- QSC KW122 — frequency-response limits
- QSC KW122 — power
- QSC KW122 — woofer size
- QSC KW153 — frequency-response limits
- QSC KW153 — power
- QSC KW153 — woofer size

## https://www.qscaudio.com/solutions-products/loudspeakers/portable/powered/portable-pa/cp-series/cp12/

- QSC CP12 — frequency-response limits
- QSC CP12 — power
- QSC CP12 — woofer size

## https://www.qscaudio.com/solutions-products/loudspeakers/portable/powered/portable-pa/k2-series/

- QSC K8.2 — frequency-response limits

## https://www.qscaudio.com/solutions-products/loudspeakers/portable/powered/subwoofers/ks-series/ks212c/

- QSC KS212C — frequency-response limits
- QSC KS212C — power
- QSC KS212C — woofer size

## https://www.qsys.com/resource-files/productresources/spk/ks/ks112/q_spk_ks_112_specs.pdf

- QSC KS112 — frequency-response limits
- QSC KS112 — power
- QSC KS112 — woofer size

## https://www.sonusfaber.com/en/products/lumina-ii/tech-specs

- Sonus Faber Lumina II — frequency-response limits
- Sonus Faber Lumina II — impedance
- Sonus Faber Lumina II — power
- Sonus Faber Lumina II — sensitivity
- Sonus Faber Lumina II — woofer size

## https://www.sonusfaber.com/en/products/lumina-iii/tech-specs

- Sonus Faber Lumina III — frequency-response limits
- Sonus Faber Lumina III — impedance
- Sonus Faber Lumina III — power
- Sonus Faber Lumina III — sensitivity
- Sonus Faber Lumina III — woofer size

## https://www.sonusfaber.com/it/prodotti/lumina-i/specifiche-tecniche

- Sonus Faber Lumina I — frequency-response limits
- Sonus Faber Lumina I — impedance
- Sonus Faber Lumina I — power
- Sonus Faber Lumina I — sensitivity
- Sonus Faber Lumina I — woofer size

## https://www.soundonsound.com/reviews/mackie-hr824

- Mackie HR824 — woofer size

## https://www.stereophile.com/content/advent-loudspeaker-specifications

- Advent The Advent Loudspeaker — impedance
- Advent The Advent Loudspeaker — power

## https://www.stereophile.com/content/quad-esl-63-loudspeaker-specifications

- Quad ESL-63 — impedance
- Quad ESL-63 — power
- Quad ESL-63 — sensitivity

## https://www.stereophile.com/content/snell-type-loudspeaker-specifications

- Snell Acoustics Type A/III — frequency-response limits
- Snell Acoustics Type A/III — impedance
- Snell Acoustics Type A/III — sensitivity
- Snell Acoustics Type A/III — woofer size

## https://www.stereophile.com/content/vandersteen-2ce-signature-loudspeaker-specifications

- Vandersteen 2Ce Signature — frequency-response limits
- Vandersteen 2Ce Signature — impedance
- Vandersteen 2Ce Signature — sensitivity
- Vandersteen 2Ce Signature — woofer size

## https://www.svsound.com/products/sb-1000-pro-subwoofer

- SVS SB-1000 Pro — frequency-response limits
- SVS SB-1000 Pro — power
- SVS SB-1000 Pro — voice-coil size
- SVS SB-1000 Pro — woofer size

## https://www.wharfedale.co.uk/collections/diamond-12-series/products/diamond-12-1

- Wharfedale Diamond 12.1 — frequency-response limits
- Wharfedale Diamond 12.1 — impedance
- Wharfedale Diamond 12.1 — power
- Wharfedale Diamond 12.1 — sensitivity
- Wharfedale Diamond 12.1 — woofer size

## https://www.wharfedale.co.uk/products/linton

- Wharfedale Linton Heritage — frequency-response limits
- Wharfedale Linton Heritage — impedance
- Wharfedale Linton Heritage — woofer size
