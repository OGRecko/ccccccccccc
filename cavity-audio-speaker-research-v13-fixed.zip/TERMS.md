# Cavity Audio — Terms of Use

**Last updated: October 4, 2026**

## 1. Use

Cavity Audio is provided for lawful acoustic-engineering, educational, evaluation, design, and related uses. The current product does not require an account, subscription, or payment.

## 2. Simulation results

Cavity Audio produces software-generated acoustic models and estimates from supplied inputs and retained speaker data. A modeled or reference response is not a laboratory measurement. The application must not represent unavailable measurements as measured data.

## 3. Responsibility for decisions

Users are responsible for validating inputs and independently checking results before relying on them for safety-critical, regulatory, structural, or acoustically critical decisions.

## 4. Hosted service

The hosted service may apply public resource limits, rate limits, temporary retention, and operational controls. Availability is not guaranteed.

## 5. Intellectual property

Cavity Audio source code, database content, documentation, and artwork are governed by the accompanying proprietary freeware license. Third-party components remain subject to their own licenses.

## 6. Warranty and liability

The detailed warranty disclaimer and limitation of liability are stated in the accompanying `LICENSE` file and apply to the extent permitted by applicable law.

## 7. Changes

The owner may update these terms together with future releases. The published version is the version applicable to the release being used.

> **Owner/legal review required before public release. This document is informational and is not legal advice.**
