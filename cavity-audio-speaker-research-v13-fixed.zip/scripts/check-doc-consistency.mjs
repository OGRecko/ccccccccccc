import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const data = JSON.parse(fs.readFileSync(path.join(root, 'src/data/speakers.json'), 'utf8'));
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const docs = {
  audit: read('AUDIT.md'),
  final: read('FINAL_VERIFICATION.md'),
  status: read('SPEAKER-DATA-STATUS.md'),
  gaps: read('SPEAKER-DATA-GAPS.md'),
};
const issues = [];
const fields = ['sensitivity','power','impedance','resonantFreq','voiceCoil','woofer'];
const count = (f) => data.filter((s) => s?.[f]?.value !== null && s?.[f]?.value !== undefined).length;
const frCount = data.filter((s) => Number.isFinite(s?.frequencyResponse?.low_hz) || Number.isFinite(s?.frequencyResponse?.high_hz)).length;
const sourced = (s) => fields.some((f) => s?.[f]?.value !== null && s?.[f]?.value !== undefined) || Number.isFinite(s?.frequencyResponse?.low_hz) || Number.isFinite(s?.frequencyResponse?.high_hz);
const status = {};
for (const s of data) status[s.overallStatus ?? 'UNSPECIFIED'] = (status[s.overallStatus ?? 'UNSPECIFIED'] ?? 0) + 1;
const expected = {
  records: data.length,
  uniqueIds: new Set(data.map((s) => s.id)).size,
  uniqueBrandModels: new Set(data.map((s) => `${s.brand}::${s.model}`.toLowerCase())).size,
  sensitivity: count('sensitivity'), power: count('power'), impedance: count('impedance'),
  resonantFreq: count('resonantFreq'), voiceCoil: count('voiceCoil'), woofer: count('woofer'), frequencyResponse: frCount,
  partial: status.PARTIALLY_VERIFIED ?? 0,
  unverified: status.UNVERIFIED ?? 0,
  unavailable: status.UNAVAILABLE ?? 0,
  anySource: data.filter(sourced).length,
  noSource: data.filter((s) => !sourced(s) && s.overallStatus !== 'UNAVAILABLE').length,
  generic: data.length - frCount,
};
if (expected.uniqueIds !== expected.records) issues.push(`duplicate IDs: ${expected.records - expected.uniqueIds}`);
if (expected.uniqueBrandModels !== expected.records) issues.push(`duplicate brand/model pairs: ${expected.records - expected.uniqueBrandModels}`);

const needles = [
  ['AUDIT records', `- ${expected.records} records`, docs.audit],
  ['AUDIT sensitivity', `sensitivity ${expected.sensitivity}`, docs.audit],
  ['AUDIT power', `power ${expected.power}`, docs.audit],
  ['AUDIT impedance', `impedance ${expected.impedance}`, docs.audit],
  ['AUDIT resonant', `resonant frequency ${expected.resonantFreq}`, docs.audit],
  ['AUDIT voice', `voice-coil size ${expected.voiceCoil}`, docs.audit],
  ['AUDIT woofer', `woofer size ${expected.woofer}`, docs.audit],
  ['AUDIT fr', `frequency-response limits ${expected.frequencyResponse}`, docs.audit],
  ['AUDIT partial', `\`PARTIALLY_VERIFIED\`: ${expected.partial}`, docs.audit],
  ['AUDIT unverified', `\`UNVERIFIED\`: ${expected.unverified}`, docs.audit],
  ['AUDIT unavailable', `\`UNAVAILABLE\`: ${expected.unavailable}`, docs.audit],
  ['STATUS partial', `- PARTIALLY_VERIFIED: ${expected.partial}`, docs.status],
  ['STATUS unverified', `- UNVERIFIED: ${expected.unverified}`, docs.status],
  ['STATUS unavailable', `- UNAVAILABLE: ${expected.unavailable}`, docs.status],
  ['STATUS sensitivity', `- Sensitivity: ${expected.sensitivity}`, docs.status],
  ['STATUS power', `- Power: ${expected.power}`, docs.status],
  ['STATUS impedance', `- Impedance: ${expected.impedance}`, docs.status],
  ['STATUS resonant', `- Resonant frequency: ${expected.resonantFreq}`, docs.status],
  ['STATUS voice', `- Voice-coil size: ${expected.voiceCoil}`, docs.status],
  ['STATUS woofer', `- Woofer size: ${expected.woofer}`, docs.status],
  ['STATUS fr', `- Frequency-response limits: ${expected.frequencyResponse}`, docs.status],
  ['STATUS generic', `- Generic reference models with missing published bounds: ${expected.generic}`, docs.status],
  ['FINAL partial', `- PARTIALLY_VERIFIED: ${expected.partial}`, docs.final],
  ['FINAL unverified', `- UNVERIFIED: ${expected.unverified}`, docs.final],
  ['FINAL unavailable', `- UNAVAILABLE: ${expected.unavailable}`, docs.final],
  ['FINAL sensitivity', `sensitivity ${expected.sensitivity}`, docs.final],
  ['FINAL power', `power ${expected.power}`, docs.final],
  ['FINAL impedance', `impedance ${expected.impedance}`, docs.final],
  ['FINAL resonant', `resonant frequency ${expected.resonantFreq}`, docs.final],
  ['FINAL voice', `voice-coil size ${expected.voiceCoil}`, docs.final],
  ['FINAL woofer', `woofer size ${expected.woofer}`, docs.final],
  ['FINAL fr', `frequency-response limits ${expected.frequencyResponse}`, docs.final],
];
for (const [name, needle, body] of needles) if (!body.includes(needle)) issues.push(`${name}: missing ${needle}`);
const old = ['Sensitivity: 39','Power: 64','Impedance: 43','Voice-coil size: 4','Woofer size: 64','Frequency-response limits: 71','PARTIALLY_VERIFIED: 772'];
for (const stale of old) if (Object.values(docs).some((body) => body.includes(stale))) issues.push(`stale documentation token: ${stale}`);
if (!docs.gaps.includes(`**Records with no source-backed physical/response field:** ${expected.noSource}`)) issues.push('speaker gap inventory total is stale');
const rowCount = (docs.gaps.match(/^\| [^|]+ \|/gm) || []).length - 1;
if (rowCount !== expected.records) issues.push(`speaker gap inventory rows: expected ${expected.records}, found ${rowCount}`);
console.log(JSON.stringify({ok: issues.length === 0, expected, issues}, null, 2));
process.exitCode = issues.length ? 1 : 0;
