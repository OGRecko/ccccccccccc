# Speaker research queue (generated from src/data/speakers.json)

Generated, not hand-edited. Regenerate with: node scripts/research/make-queue.mjs

Records still needing research: **582** of 774 (579 UNVERIFIED, 3 UNAVAILABLE) across 98 brands.

Rules for every entry: exact model + revision; manufacturer page/manual/datasheet fetched (not a search snippet); populated fields carry their URL; anything unpublished stays N/A. Some discontinued or legacy models will have NO online manufacturer data and must stay UNVERIFIED.

| Brand | Remaining | Models |
|---|---|---|
| Electro-Voice | 60 | Force i (`eV-force-i`); ZLX-15P (`eV-zlx15p`); Live X X2 (`eV-live-x2`); Sentry 500 (`eV-sentry-500`); ZLX-12P (`eV-zlx12p`); ETX-12P (`eV-etx12p`); EVERSE 8 (`electro-voice-everse-8`); EVERSE 12 (`electro-voice-everse-12`); ZLX-8-G2 (`electro-voice-zlx-8-g2`); ZLX-12-G2 (`electro-voice-zlx-12-g2`); ZLX-15-G2 (`electro-voice-zlx-15-g2`); ELX200-10P (`electro-voice-elx200-10p`); ELX200-12P (`electro-voice-elx200-12p`); ELX200-15P (`electro-voice-elx200-15p`); ELX200-10 (`electro-voice-elx200-10`); ELX200-12 (`electro-voice-elx200-12`); ELX200-15 (`electro-voice-elx200-15`); ELX200-12SP (`electro-voice-elx200-12sp`); ELX200-12S (`electro-voice-elx200-12s`); ELX200-18S (`electro-voice-elx200-18s`); EVOLVE 30M (`electro-voice-evolve-30m`); EVOLVE 50 (`electro-voice-evolve-50`); EVOLVE 50M (`electro-voice-evolve-50m`); EVOLVE 70 (`electro-voice-evolve-70`); EVOLVE 90 (`electro-voice-evolve-90`); PXM-12MP (`electro-voice-pxm-12mp`); ZX1 (`electro-voice-zx1`); ZX1i (`electro-voice-zx1i`); ZX3 (`electro-voice-zx3`); ZX4 (`electro-voice-zx4`); ZX5 (`electro-voice-zx5`); Sx300PI (`electro-voice-sx300pi`); Sx300PIX (`electro-voice-sx300pix`); Sx100+ (`electro-voice-sx100`); Sx300E (`electro-voice-sx300e`); Sx600 (`electro-voice-sx600`); Sb122 (`electro-voice-sb122`); TX1122 (`electro-voice-tx1122`); TX1122FM (`electro-voice-tx1122fm`); TX1152 (`electro-voice-tx1152`); TX1152FM (`electro-voice-tx1152fm`); TX1181 (`electro-voice-tx1181`); TX2152 (`electro-voice-tx2152`); TX2181 (`electro-voice-tx2181`); EKX-12 (`electro-voice-ekx-12`); EKX-15 (`electro-voice-ekx-15`); EKX-15SP (`electro-voice-ekx-15sp`); EKX-18SP (`electro-voice-ekx-18sp`); EKX-15S (`electro-voice-ekx-15s`); EKX-18S (`electro-voice-ekx-18s`); ETX-10P (`electro-voice-etx-10p`); ETX-35P (`electro-voice-etx-35p`); ETX-15SP (`electro-voice-etx-15sp`); ETX-18SP (`electro-voice-etx-18sp`); ELX112 (`electro-voice-elx112`); ELX115 (`electro-voice-elx115`); ELX215 (`electro-voice-elx215`); EVF-1152D (`electro-voice-evf-1152d`); EVF-1152D/96 (`electro-voice-evf-1152d-96`); X12-128 (`electro-voice-x12-128`) |
| Bose | 30 | 4.2LE (`bose-4.2le`); Acoustimass 10 (`bose-acoustimass-10`); Lifestyle Cube Speaker (`bose-lifestyle-cube`); L1 Compact (`bose-l1-compact`); S1 Pro (`bose-s1-pro`); Sub1 (`bose-sub1`); FreeSpace 3 (`bose-freespace-3`); Virtually Invisible 791 (`bose-virtually-invisible-791`); FreeSpace DS 16S (`bose-freespace-ds16s`); FreeSpace DS 40SE (`bose-freespace-ds40se`); FreeSpace DS 100SE (`bose-freespace-ds100se`); DesignMax DM3SE (`bose-designmax-dm3se`); DesignMax DM6SE (`bose-designmax-dm6se`); DesignMax DM8SE (`bose-designmax-dm8se`); DesignMax DM10SE (`bose-designmax-dm10se`); 301 Series IV (`bose-301`); Wave Music System IV (`bose-wave-music-system`); 501 (`legacy-bose-2`); 802 (`legacy-bose-3`); 402 (`legacy-bose-4`); FreeSpace DS 16F (`legacy-bose-6`); 251 Environmental (`legacy-bose-7`); Bose Home Speaker 500 (`bose-bose-home-speaker-500`); Bose Home Speaker 300 (`bose-bose-home-speaker-300`); Bose Portable Smart Speaker (`bose-bose-portable-smart-speaker`); Bose SoundLink Flex (`bose-bose-soundlink-flex`); Bose SoundLink Max (`bose-bose-soundlink-max`); Bose Smart Ultra Soundbar (`bose-bose-smart-ultra-soundbar`); Bose Smart Soundbar (`bose-bose-smart-soundbar`); Bose TV Speaker (`bose-bose-tv-speaker`) |
| KEF | 29 | LS50 (`kef-ls50`); LS50 Wireless II (`kef-ls50-wireless`); R11 (`kef-r11`); LS3/5a (`kef-ls3-5a`); R3 (`kef-r3`); R5 (`kef-r5`); Reference 1 (`kef-reference-1`); Reference 5 (`kef-reference-5`); Concord (`legacy-kef-1`); Model 104 (`legacy-kef-2`); Model 103 (`legacy-kef-3`); Reference 105 (`legacy-kef-4`); Q100 (`legacy-kef-5`); Blade (`legacy-kef-7`); Ci200 (`legacy-kef-10`); R3 Meta (`kef-r3-meta`); Reference 1 Meta (`kef-reference-1-meta`); R5 Meta (`kef-r5-meta`); R7 Meta (`kef-r7-meta`); Reference 3 Meta (`kef-reference-3-meta`); Reference 5 Meta (`kef-reference-5-meta`); Blade Meta (`kef-blade-meta`); Blade Two Meta (`kef-blade-two-meta`); LSX II (`kef-lsx-ii`); KF92 (`kef-kf92`); KUBE-8b (`kef-kube-8b`); KUBE-10b (`kef-kube-10b`); KUBE-12b (`kef-kube-12b`); R7 (`kef-r7`) |
| JBL | 27 | 4350 (`jbl-4350`); EON15 (`jbl-eon15`); 4412 (`jbl-4412`); LSR32 (`jbl-lsr32`); PRX815W (`jbl-prx815w`); Charge 5 (`jbl-charge5`); Flip 6 (`jbl-flip6`); PartyBox 1000 (`jbl-partybox-1000`); SRX828SP (`jbl-srx828sp`); JRX225 (`jbl-jrx225`); SRX815 (`jbl-srx815`); VRX932LA (`jbl-vrx932`); VTX A12 (`jbl-vtx-a12`); L16 (`jbl-l16`); L19 (`jbl-l19`); Everest DD67000 (`jbl-everest-dd67000`); 4312 (`jbl-4312`); Paragon D44000 (`jbl-paragon`); K2 S9900 (`jbl-k2-s9900`); Control 52 (`jbl-control-52`); Control 30 (`jbl-control-30`); D130 (`legacy-jbl-1`); Ranger Paragon D44000 (`legacy-jbl-2`); 4310 Studio Monitor (`legacy-jbl-3`); 4311 Studio Monitor (`legacy-jbl-5`); 4430 Studio Monitor (`legacy-jbl-6`); Control 25 (`legacy-jbl-11`) |
| Klipsch | 27 | KG 4.5 (`klipsch-kg4`); CDT-5650-C II (`klipsch-cdt5650c`); Cornwall IV (`klipsch-cornwall-iv`); Forte IV (`klipsch-forte-iv`); La Scala II (`klipsch-la-scala-ii`); Heresy IV (`klipsch-heresy-iv`); RP-8060FA II (`klipsch-rp8060fa`); RP-6000F II (`klipsch-rp6000f`); RP-600M II (`klipsch-rp600m`); RP-500M II (`klipsch-rp500m`); AWR-650-SM (`klipsch-awr650sm`); Cornwall (`legacy-klip-3`); La Scala (`legacy-klip-4`); Forte (`legacy-klip-5`); RF-7 III (`legacy-klip-6`); R-41M (`legacy-klip-8`); RP-500M (`klipsch-rp-500m`); RP-600M (`klipsch-rp-600m`); RP-5000F II (`klipsch-rp-5000f-ii`); RP-8000F II (`klipsch-rp-8000f-ii`); RF-8000F (`klipsch-rf-8000f`); R-120SW (`klipsch-r-120sw`); R-121SW (`klipsch-r-121sw`); SPL-100 (`klipsch-spl-100`); SPL-120 (`klipsch-spl-120`); SPL-150 (`klipsch-spl-150`); CDT-5800-C II (`klipsch-cdt-5800-c-ii`) |
| Focal | 26 | Scala Utopia III (`focal-utopia-scala`); Chorus 707 (`legacy-focal-1`); Electra 1027Be (`legacy-focal-2`); Utopia III Scala (`legacy-focal-3`); Trio6 Be (`legacy-focal-5`); Kanta No2 (`legacy-focal-7`); Aria 906 (`legacy-focal-8`); Alpha 80 Evo (`focal-alpha-80-evo`); Shape 80 (`focal-shape-80`); Trio6 (`focal-trio6`); Chora 806 (`focal-chora-806`); Chora 826 (`focal-chora-826`); Aria 926 (`focal-aria-926`); Aria 936 (`focal-aria-936`); Aria 948 (`focal-aria-948`); Kanta N°1 (`focal-kanta-n-1`); Kanta N°2 (`focal-kanta-n-2`); Kanta N°3 (`focal-kanta-n-3`); Sopra N°1 (`focal-sopra-n-1`); Sopra N°2 (`focal-sopra-n-2`); Sopra N°3 (`focal-sopra-n-3`); Scala Utopia Evo (`focal-scala-utopia-evo`); Maestro Utopia Evo (`focal-maestro-utopia-evo`); Grande Utopia EM Evo (`focal-grande-utopia-em-evo`); Sub One (`focal-sub-one`); Sub6 (`focal-sub6`) |
| Bowers & Wilkins | 24 | 802 D3 (`bw-802d3`); 802 (1979 original) (`bw-802-original`); 800 D4 (`bw-800-d4`); 803 D4 (`bw-803-d4`); DM6 (`legacy-bw-1`); 801 (`legacy-bw-2`); Matrix 801 (`legacy-bw-3`); Nautilus (`legacy-bw-4`); 802D (`legacy-bw-5`); CM10 (`legacy-bw-6`); 800 D3 (`legacy-bw-7`); CWM8 (`legacy-bw-9`); CCM8 (`legacy-bw-10`); 804 D4 (`bowers-wilkins-804-d4`); 702 S3 (`bowers-wilkins-702-s3`); 704 S3 (`bowers-wilkins-704-s3`); Formation Flex (`bowers-wilkins-formation-flex`); Formation Wedge (`bowers-wilkins-formation-wedge`); Zeppelin (`bowers-wilkins-zeppelin`); DB1D (`bowers-wilkins-db1d`); DB2D (`bowers-wilkins-db2d`); DB3D (`bowers-wilkins-db3d`); DB4S (`bowers-wilkins-db4s`); ASW610 (`bowers-wilkins-asw610`) |
| Dynaudio | 21 | Contour 1.3 (`legacy-dyn-1`); Special Twenty-Five (`legacy-dyn-2`); Confidence C1 (`legacy-dyn-3`); Evidence Platinum (`legacy-dyn-4`); Contour 20 (`legacy-dyn-7`); Core 7 (`dynaudio-core-7`); Core 47 (`dynaudio-core-47`); Core 59 (`dynaudio-core-59`); Emit 10 (`dynaudio-emit-10`); Emit 20 (`dynaudio-emit-20`); Emit 30 (`dynaudio-emit-30`); Evoke 10 (`dynaudio-evoke-10`); Evoke 20 (`dynaudio-evoke-20`); Evoke 30 (`dynaudio-evoke-30`); Evoke 50 (`dynaudio-evoke-50`); Contour 20i (`dynaudio-contour-20i`); Contour 30i (`dynaudio-contour-30i`); Contour 60i (`dynaudio-contour-60i`); Confidence 20 (`dynaudio-confidence-20`); Confidence 30 (`dynaudio-confidence-30`); Confidence 50 (`dynaudio-confidence-50`) |
| Sonos | 20 | One (`sonos-one`); Five (`sonos-five`); Sub Mini (`sonos-sub-mini`); Arc (`sonos-arc`); Beam Gen 2 (`sonos-beam`); Play:1 (`sonos-play1`); Play:3 (`sonos-play3`); Play:5 (`sonos-play5`); ZonePlayer 100 (`legacy-sonos-1`); Move (`legacy-sonos-5`); Era 300 (`legacy-sonos-6`); Sonos Era 100 (`sonos-sonos-era-100`); Sonos Era 300 (`sonos-sonos-era-300`); Sonos Five (`sonos-sonos-five`); Sonos Move 2 (`sonos-sonos-move-2`); Sonos Roam 2 (`sonos-sonos-roam-2`); Sonos Arc (`sonos-sonos-arc`); Sonos Arc Ultra (`sonos-sonos-arc-ultra`); Sonos Beam (`sonos-sonos-beam`); Sonos Ray (`sonos-sonos-ray`) |
| QSC | 18 | CP15 (`qsc-cp15`); LA108 (`qsc-la108`); LA112 (`qsc-la112`); LS118 (`qsc-ls118`); E218SW (`qsc-e218sw`); AD-C4T (`qsc-ad-c4t`); AD-C6T (`qsc-ad-c6t`); AD-C8T (`qsc-ad-c8t`); AC-C4T (`qsc-ac-c4t`); AC-C6T (`qsc-ac-c6t`); AC-C8T (`qsc-ac-c8t`); WL3082 (`qsc-wl3082`); WL2102w (`qsc-wl2102w`); WL212-sw (`qsc-wl212-sw`); WL218-sw (`qsc-wl218-sw`); GP118-sw (`qsc-gp118-sw`); GP212-sw (`qsc-gp212-sw`); GP218-sw (`qsc-gp218-sw`) |
| Monitor Audio | 15 | Silver 500 (`monitor-audio-silver-500`); Bronze 50 (`monitor-audio-bronze-50`); Bronze 100 (`monitor-audio-bronze-100`); Bronze 200 (`monitor-audio-bronze-200`); Bronze 500 (`monitor-audio-bronze-500`); Silver 50 (`monitor-audio-silver-50`); Silver 100 (`monitor-audio-silver-100`); Silver 300 (`monitor-audio-silver-300`); Creator Q50 (`monitor-audio-creator-q50`); Creator Q250 (`monitor-audio-creator-q250`); Creator C1M (`monitor-audio-creator-c1m`); Creator C2M (`monitor-audio-creator-c2m`); Creator C3M (`monitor-audio-creator-c3m`); Platinum 100 3G (`monitor-audio-platinum-100-3g`); Platinum 200 3G (`monitor-audio-platinum-200-3g`) |
| Mackie | 14 | SRM550 (`mackie-srm550`); SRM212 V-Class (`mackie-srm212`); HR624 (`legacy-mack-2`); MR624 (`legacy-mack-3`); CR3 (`legacy-mack-4`); Thump15 (`legacy-mack-5`); SRM450 (`legacy-mack-6`); DLM12 (`legacy-mack-7`); CR3-X (`mackie-cr3-x`); CR4-X (`mackie-cr4-x`); CR5-X (`mackie-cr5-x`); MR524 (`mackie-mr524`); MR824 (`mackie-mr824`); Thump215XT (`mackie-thump215xt`) |
| Marshall | 12 | Marshall 1960A (`marshall-marshall-1960a`); Marshall 1960B (`marshall-marshall-1960b`); Marshall 1960AV (`marshall-marshall-1960av`); Marshall 1960BV (`marshall-marshall-1960bv`); Marshall 1936 (`marshall-marshall-1936`); Marshall 1936V (`marshall-marshall-1936v`); Marshall MX112 (`marshall-marshall-mx112`); Marshall MX212 (`marshall-marshall-mx212`); Marshall Acton III (`marshall-marshall-acton-iii`); Marshall Stanmore III (`marshall-marshall-stanmore-iii`); Marshall Woburn III (`marshall-marshall-woburn-iii`); Marshall Middleton (`marshall-marshall-middleton`) |
| JL Audio | 11 | 12W7AE-3 (`jl-audio-12w7`); C1-650 (`jl-audio-c1-650`); C2-650 (`jl-audio-c2-650`); C3-650 (`jl-audio-c3-650`); C5-650 (`jl-audio-c5-650`); C7-650 (`jl-audio-c7-650`); 10W0v3 (`jl-audio-10w0v3`); 12W0v3 (`jl-audio-12w0v3`); 10W3v3 (`jl-audio-10w3v3`); 12W3v3 (`jl-audio-12w3v3`); 13W7AE (`jl-audio-13w7ae`) |
| Sonus Faber | 11 | Sonetto I (`sonus-faber-sonetto-i`); Sonetto II (`sonus-faber-sonetto-ii`); Sonetto III (`sonus-faber-sonetto-iii`); Sonetto V (`sonus-faber-sonetto-v`); Olympica Nova I (`sonus-faber-olympica-nova-i`); Olympica Nova II (`sonus-faber-olympica-nova-ii`); Olympica Nova III (`sonus-faber-olympica-nova-iii`); Olympica Nova V (`sonus-faber-olympica-nova-v`); Homage Tradition Amati (`sonus-faber-homage-tradition-amati`); Homage Tradition Guarneri (`sonus-faber-homage-tradition-guarneri`); Homage Tradition Serafino (`sonus-faber-homage-tradition-serafino`) |
| DALI | 10 | Oberon 9 (`dali-oberon-9`); Opticon 2 MK2 (`dali-opticon-2-mk2`); Opticon 6 MK2 (`dali-opticon-6-mk2`); Opticon 8 MK2 (`dali-opticon-8-mk2`); Rubicon 2 (`dali-rubicon-2`); Rubicon 6 (`dali-rubicon-6`); Rubicon 8 (`dali-rubicon-8`); Epicon 2 (`dali-epicon-2`); Epicon 6 (`dali-epicon-6`); Epicon 8 (`dali-epicon-8`) |
| SVS | 9 | PB16-Ultra (`svs-pb16-ultra`); SB-2000 Pro (`svs-sb-2000-pro`); SB-3000 (`svs-sb-3000`); SB4000 (`svs-sb4000`); SB16-Ultra (`svs-sb16-ultra`); PB-1000 Pro (`svs-pb-1000-pro`); PB-2000 Pro (`svs-pb-2000-pro`); PB-3000 (`svs-pb-3000`); PB-4000 (`svs-pb-4000`) |
| Pioneer | 9 | CS-99A (`legacy-pio-1`); HPM-100 (`legacy-pio-2`); CS-88A (`legacy-pio-3`); Elite S-1EX (`legacy-pio-4`); SP-BS22-LR (`legacy-pio-5`); SP-FS52 (`legacy-pio-6`); TS-A1607F (`pioneer-ts-a1607f`); TS-Z65F (`pioneer-ts-z65f`); TS-D65C (`pioneer-ts-d65c`) |
| Polk Audio | 8 | RTi A7 (`polk-rti-a7`); RC85i (`polk-rc85i`); Signature S50 (`polk-signature-s50`); Signature S15 (`polk-signature-s15`); Reserve R100 (`polk-audio-reserve-r100`); Reserve R200 (`polk-audio-reserve-r200`); Signature Elite ES15 (`polk-audio-signature-elite-es15`); Signature Elite ES20 (`polk-audio-signature-elite-es20`) |
| PreSonus | 8 | Eris E5 (`presonus-eris-e5`); Eris 3.5 (`presonus-eris-3-5`); Eris 4.5 (`presonus-eris-4-5`); Eris 5 (`presonus-eris-5`); Eris 6 (`presonus-eris-6`); Eris 8 (`presonus-eris-8`); R65 (`presonus-r65`); R80 (`presonus-r80`) |
| L-Acoustics | 8 | ARCS Wide (`lacoustics-arcs`); V-DOSC (`legacy-la-1`); ARCS (`legacy-la-2`); Kara (`legacy-la-3`); K1 (`legacy-la-4`); K2 (`legacy-la-5`); Syva (`legacy-la-6`); X15 (`legacy-la-7`) |
| Yamaha | 8 | NS-500 (`yamaha-ns500`); NS-6490 (`yamaha-ns-6490`); NS-777 (`yamaha-ns-777`); NS-5000 (`yamaha-ns-5000`); NS-10M (`legacy-yam-2`); NS-690 (`legacy-yam-3`); VXC series (`legacy-yam-8`); DXS12 (`yamaha-dxs12`) |
| Adam Audio | 7 | S3X-V (`adam-s3x`); A4V (`adam-a4v`); A5X (`adam-a5x`); A8H (`adam-a8h`); S3A (`legacy-adam-1`); A7V (`legacy-adam-4`); S2V (`legacy-adam-6`) |
| ADAM Audio | 7 | T7V (`adam-audio-t7v`); T8V (`adam-audio-t8v`); A44H (`adam-audio-a44h`); A77H (`adam-audio-a77h`); S3H (`adam-audio-s3h`); S3V (`adam-audio-s3v`); S5H (`adam-audio-s5h`) |
| Fender | 7 | Twin Reverb (`fender-twin-reverb`); Deluxe Reverb (`fender-deluxe-reverb`); Blues Junior IV (`fender-blues-junior-iv`); Hot Rod Deluxe (`fender-hot-rod-deluxe`); Princeton Reverb (`fender-princeton-reverb`); Super Reverb (`fender-super-reverb`); Bassman 410 (`fender-bassman-410`) |
| Bang & Olufsen | 6 | Beovox S45 (`bang-olufsen-beovox-s45`); BeoLab 5 (`beolab-5`); Beosound A5 (`bang-olufsen-beosound-a5`); Beosound 2 (`bang-olufsen-beosound-2`); Beosound Balance (`bang-olufsen-beosound-balance`); Beosound Level (`bang-olufsen-beosound-level`) |
| Samsung | 6 | Samsung HW-Q990D (`samsung-samsung-hw-q990d`); Samsung HW-Q990F (`samsung-samsung-hw-q990f`); Samsung HW-Q930D (`samsung-samsung-hw-q930d`); Samsung HW-Q800D (`samsung-samsung-hw-q800d`); Samsung HW-Q700D (`samsung-samsung-hw-q700d`); Samsung HW-S800D (`samsung-samsung-hw-s800d`) |
| Rockford Fosgate | 5 | Punch P3D4-12 (Dual 4Ω) (`rockford-fosgate-p3`); R165X3 (`rockford-fosgate-r165x3`); R1675X2 (`rockford-fosgate-r1675x2`); T1650 (`rockford-fosgate-t1650`); T1650-S (`rockford-fosgate-t1650-s`) |
| Wharfedale | 5 | W60 (`wharfedale-w60`); Diamond 12.0 (`wharfedale-diamond-12-0`); Diamond 12.2 (`wharfedale-diamond-12-2`); EVO4.1 (`wharfedale-evo4-1`); EVO4.2 (`wharfedale-evo4-2`) |
| Sony | 5 | Sony BRAVIA Theatre Bar 9 (`sony-sony-bravia-theatre-bar-9`); Sony BRAVIA Theatre Bar 8 (`sony-sony-bravia-theatre-bar-8`); Sony HT-A7000 (`sony-sony-ht-a7000`); Sony HT-A5000 (`sony-sony-ht-a5000`); Sony HT-A3000 (`sony-sony-ht-a3000`) |
| Orange | 5 | Orange PPC108 (`orange-orange-ppc108`); Orange PPC112 (`orange-orange-ppc112`); PPC212 (`orange-ppc212`); PPC212V (`orange-ppc212v`); PPC412 (`orange-ppc412`) |
| PMC | 5 | result6 (`pmc-result6`); PMC6-2 (`pmc-pmc6-2`); PMC8-2 (`pmc-pmc8-2`); TB2 (`pmc-tb2`); BB5 (`pmc-bb5-xbd-a`) |
| KRK | 4 | 7000B (`krk-7000`); Rokit 5 G1 (`krk-rokit-5`); Rokit 8 G3 (`krk-rokit-8`); V6 S4 (`krk-v6-s4`) |
| Genelec | 4 | 8020C (`genelec-8020c`); 7060C (`genelec-7060c`); S30 (`legacy-gen-1`); 4430 (`legacy-gen-8`) |
| ATC | 4 | SCM19 (`atc-scm19`); SCM45A Pro (`atc-scm45a-pro`); SCM50ASL Pro (`atc-scm50asl-pro`); SCM100ASL Pro (`atc-scm100asl-pro`) |
| Martin Audio | 4 | Wavefront 8 (`legacy-ma-1`); F2 (`legacy-ma-2`); W8LM (`legacy-ma-3`); MLA (`legacy-ma-4`) |
| LG | 4 | LG S95TR (`lg-lg-s95tr`); LG S90TR (`lg-lg-s90tr`); LG S80TR (`lg-lg-s80tr`); LG SC9S (`lg-lg-sc9s`) |
| Kicker | 4 | 43DSC6504 (`kicker-43dsc6504`); 47KSC6504 (`kicker-47ksc6504`); 46CSS674 (`kicker-46css674`); 46CSC654 (`kicker-46csc654`) |
| Q Acoustics | 4 | 3010i (`q-acoustics-3010i`); 3020i (`q-acoustics-3020i`); 3030i (`q-acoustics-3030i`); 5020 (`q-acoustics-5020`) |
| Mesa/Boogie | 4 | Rectifier 4x12 (`mesa-boogie-rectifier-4x12`); 2x12 Rectifier (`mesa-boogie-2x12-rectifier`); Fillmore 2x12 (`mesa-boogie-fillmore-2x12`); Lone Star 2x12 (`mesa-boogie-lone-star-2x12`) |
| Infinity | 3 | RS-1B (`infinity-rs1`); Kappa 9 (`infinity-kappa-9`); IRS V (`infinity-irs-v`) |
| Revel | 3 | F206 (`revel-f206`); M106 (`revel-m106`); Ultima Salon2 (`revel-ultima-salon2`) |
| Peavey | 3 | SP 2 (`peavey-sp2`); 6505 412 (`peavey-6505-412`); 5150 412 (`peavey-5150-412`) |
| Hertz | 3 | Dieci DSK 165.3 (`hertz-dieci-dsk-165-3`); Cento CK 165 (`hertz-cento-ck-165`); Mille Pro MPK 165.3 (`hertz-mille-pro-mpk-165-3`) |
| Alpine | 3 | S-S65 (`alpine-s-s65`); R-S65C (`alpine-r-s65c`); X-S65C (`alpine-x-s65c`) |
| Morel | 3 | Maximo Ultra 602 (`morel-maximo-ultra-602`); Virtus 602 (`morel-virtus-602`); Elate Carbon 62A (`morel-elate-carbon-62a`) |
| Audison | 3 | Prima APK 165 (`audison-prima-apk-165`); Voce AV K6 (`audison-voce-av-k6`); Thesis TH K2 II A (`audison-thesis-th-k2-ii-a`) |
| Triangle | 3 | Borea BR02 (`triangle-borea-br02`); Borea BR03 (`triangle-borea-br03`); Comete Ez (`triangle-comete-ez`) |
| Vox | 3 | V212C (`vox-v212c`); V212HWX (`vox-v212hwx`); V212BN (`vox-v212bn`) |
| Sennheiser | 3 | AMBEO Soundbar Max (`sennheiser-ambeo-soundbar-max`); AMBEO Soundbar Plus (`sennheiser-ambeo-soundbar-plus`); AMBEO Mini (`sennheiser-ambeo-mini`) |
| Cerwin Vega | 2 | D-9 (`cerwin-vega-d9`); Earthquake (`cerwin-vega-earthquake`) |
| Boston Acoustics | 2 | A150 (`boston-a150`); VR-M50 (`boston-vr-m50`) |
| RCF | 2 | ART 312-A MK5 (`rcf-art312a`); NX 45-A (`rcf-nx45a`) |
| Turbosound | 2 | iP15B (`turbosound-ip15b`); TCS-115 (`turbosound-tcs-115`) |
| Sonus faber | 2 | Olympica III (`sonus-faber-olympica3`); Guarneri Evolution (`sonus-faber-guarneri`) |
| Kali Audio | 2 | LP-6 (`kali-lp6`); IN-8 (`kali-in8`) |
| Wilson Audio | 2 | WATT/Puppy 8 (`wilson-watt-puppy`); Alexia (`wilson-audio-alexia`) |
| MartinLogan | 2 | Motion 40 (`martinlogan-motion-40`); Motion 20 (`martinlogan-motion-20`) |
| Kenwood | 2 | KFC-1666S (`kenwood-kfc-1666s`); Excelon KFC-XP6903C (`kenwood-excelon-kfc-xp6903c`) |
| KLH | 1 | Model Six (`klh-model-6`) |
| ELAC | 1 | Uni-Fi UB5 (`elac-uni-fi-ub5`) |
| dB Technologies | 1 | Opera 405 (`dbtechnologies-opera-405`) |
| Avantone | 1 | Mixcube (`ath-avantone-mixcube`) |
| Community | 1 | CS215 (`community-cs215`) |
| Meyer Sound | 1 | MJF-212 (`meyer-mjf212`) |
| d&b audiotechnik | 1 | T10 (`dandb-t10`) |
| Nexo | 1 | PS15 (`nexo-ps15`) |
| Funktion-One | 1 | Res 2 (`funktion-one-res2`) |
| Behringer | 1 | B215XL (`behringer-b215xl`) |
| DAS Audio | 1 | Aero 12A (`das-audio-aero-12a`) |
| Harbeth | 1 | Super HL5 Plus (`harbeth-shl5`) |
| Spendor | 1 | SP100 (`spendor-sp100`) |
| ProAc | 1 | Response D2 (`proac-response-d2`) |
| Thiel | 1 | CS2.4 (`thiel-cs2.4`) |
| Magnepan | 1 | MG 1.7 (`magnepan-mg1.7`) |
| Apogee Acoustics | 1 | Scintilla (`apogee-scintilla`) |
| Auratone | 1 | 5C Sound Cube (`auratone-5c`) |
| Fostex | 1 | 6301B (`fostex-6301b`) |
| Equator Audio | 1 | D5 (`equator-d5`) |
| EAW | 1 | KF760 (`eaw-kf760`) |
| Adamson | 1 | E15 (`adamson-e15`) |
| Void Acoustics | 1 | Air 8 (`void-air-8`) |
| Danley Sound Labs | 1 | SH-96 (`danley-sh96`) |
| Rogers | 1 | LS3/5a (`rogers-ls3-5a`) |
| Tannoy | 1 | Autograph (`tannoy-autograph`) |
| Ohm Acoustics | 1 | Walsh 2 (`ohm-walsh-2`) |
| Apple | 1 | HomePod (2nd gen) (`apple-homepod`) |
| Amazon | 1 | Echo (4th gen) (`amazon-echo`) |
| REL Acoustics | 1 | S/812 (`rel-s812`) |
| Totem Acoustic | 1 | Model 1 (`totem-model1`) |
| PSB | 1 | Synchrony T600 (`psb-synchrony-t600`) |
| Bryston | 1 | Model T (`bryston-model-t`) |
| Sonance | 1 | Mariner 6 (`sonance-mariner-6`) |
| Devialet | 1 | Dione (`devialet-dione`) |
| Barefoot Sound | 1 | Footprint03 (`barefoot-footprint03`) |
| HEDD | 1 | Type 20 (`hedd-type-20`) |
| IK Multimedia | 1 | iLoud MTM (`ik-multimedia-iloud-mtm`) |
| Dutch & Dutch | 1 | 8c (`dutch-and-dutch-8c`) |
