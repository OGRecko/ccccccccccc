// Applies a source-pinned research batch to src/data/speakers.json.
// Usage: node scripts/research/apply-batch.mjs scripts/research/batch-001.json
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const dsPath = path.join(root, 'src/data/speakers.json');
const data = JSON.parse(fs.readFileSync(dsPath, 'utf8'));
const batch = JSON.parse(fs.readFileSync(path.resolve(process.argv[2]), 'utf8'));
const statusFor = (t) => t === 'MANUFACTURER' ? 'MANUFACTURER_VERIFIED' : t === 'MEASUREMENT' ? 'MEASUREMENT_VERIFIED' : 'REPUTABLE_DATABASE_VERIFIED';
for (const e of batch) {
  const s = data.find((x) => x.id === e.id);
  if (!s) throw new Error(`unknown id ${e.id}`);
  if (!String(s.model).includes(e.model_check)) throw new Error(`${e.id}: model mismatch`);
  if (!/^https:\/\//.test(e.source)) throw new Error(`${e.id}: source must be URL`);
  for (const [f, v] of Object.entries(e.fields)) {
    s[f] = { ...(s[f] || {}), ...v, status: statusFor(e.sourceType), source: e.source, sourceType: e.sourceType };
  }
  // Optional top-level structural facts (driverCount / active / panel). Only these keys are accepted, and only
  // alongside a source-pinned entry; their provenance is the entry's `source`, quoted in `notes`.
  for (const [k, v] of Object.entries(e.scalars || {})) {
    if (!['driverCount', 'active', 'panel'].includes(k)) throw new Error(`${e.id}: scalar ${k} not allowed`);
    s[k] = v;
  }
  if (e.notes) s.notes = e.notes;
  s.overallStatus = 'PARTIALLY_VERIFIED';
}
fs.writeFileSync(dsPath, JSON.stringify(data, null, 2) + '\n');
console.log(`applied ${batch.length} entries`);
