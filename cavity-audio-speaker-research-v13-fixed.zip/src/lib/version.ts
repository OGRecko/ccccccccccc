export const APP_VERSION = "3.1.0";
export const SOLVER_VERSION = "1.3.0";
export const SPEAKER_DATABASE_VERSION = "2.0.0";
export const MATERIAL_DATABASE_VERSION = "1.1.0";
export const SCHEMA_VERSION = 3;
